Firefox replay for the published browser compiler

Requires Node, Firefox, and geckodriver. This runner uses snap Firefox on Ubuntu.
Download https://vektorflow.org/downloads/current/vkf-browser-compiler.zip and extract its compiler.mjs, compiler.wasm, compiler.data into ./package/. Verify SHA256 against the results JSON before running.
Run: taskset -c 4,5,12,13 node run-firefox-bench.mjs

Each supported unchanged source has three warmups and ten single-entry samples. VM reset, formatting, result validation, frontend compilation, package load and factory initialization are outside the raw-operation timer. Separate frontend compile measurements use an already initialized canonical compiler. No cold-browser startup metric is claimed.
Combined-parallel runs on one Firefox main thread; no browser parallel speedup is claimed. Standalone n-body remains unsupported and is not replaced.

Sources: VKF benchmark adaptations of the Computer Language Benchmarks Game spectral-norm, fannkuch-redux, and n-body numerical tasks. Original task descriptions: https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/spectralnorm.html, https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/fannkuchredux.html, https://benchmarksgame-team.pages.debian.net/benchmarksgame/description/nbody.html. Exact included source and SHA256 define each workload.
Runtime wrapper files retain the site license in LICENSE-runtime.txt. Compiler package includes its own source notices.
