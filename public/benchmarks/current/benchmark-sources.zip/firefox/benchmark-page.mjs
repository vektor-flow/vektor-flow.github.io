import factory from '/package/compiler.mjs';
import {createCanonicalBrowserCompiler} from '/runtime/playground/vkf-canonical-browser-compiler.mjs';
const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
const wasmBinary=await (await fetch('/package/compiler.wasm')).arrayBuffer(),data=await (await fetch('/package/compiler.data')).arrayBuffer();
let owner;const compiler=await createCanonicalBrowserCompiler({factory:async o=>owner=await factory(o),wasmBinary,getPreloadedPackage:()=>data});
const configuration=await (await fetch('/config.json')).json();
const stats=values=>{const sorted=[...values].sort((a,b)=>a-b),mean=values.reduce((a,b)=>a+b,0)/values.length;return {samples_ms:values,median_ms:(sorted[4]+sorted[5])/2,mean_ms:mean,sample_standard_deviation_ms:Math.sqrt(values.reduce((s,v)=>s+(v-mean)**2,0)/(values.length-1))};};
window.ready=true;
window.runCase=async function(name){
 const cfg=configuration.rows.find(r=>r.case===name);const source=await(await fetch('/programs/'+name+'.vkf')).text();
 if(await sha(new TextEncoder().encode(source))!==cfg.source_sha256)throw Error('source SHA mismatch');
 const program=compiler.compileSource(source,'/browser/'+name+'.vkf');const module=await WebAssembly.compile(program.wasm),instance=new WebAssembly.Instance(module),vm=instance.exports;
 const row={case:name,source_sha256:cfg.source_sha256,wasm_sha256:await sha(program.wasm),expected_value:cfg.expected_value,imports:WebAssembly.Module.imports(module),selected_workers:0,execution_mode:'single Firefox main thread',warmups:3,operations_per_sample:1,metric:'performance.now around vkf_vm_invoke only; VM reset and compiler-owned formatting outside timer',samples:[]};
 function format(){const used=Math.max(vm.vkf_vm_heap_ptr(),vm.vkf_vm_results_ptr()+vm.vkf_vm_value_slot_size()),pointer=owner._malloc(used);try{owner.HEAPU8.set(new Uint8Array(vm.memory.buffer,0,used),pointer);const status=owner.ccall('vkf_browser_format_stdout','number',['number','number','number'],[pointer,used,vm.vkf_vm_results_ptr()]);if(status)throw Error('format failure '+status);return owner.ccall('vkf_browser_stdout','string',[],[]);}finally{owner._free(pointer);}}
 for(let i=-3;i<10;i++){vm.vkf_vm_reset();const start=performance.now(),status=vm.vkf_vm_invoke(program.manifest.functions.$vkf_main.index,0),elapsed=performance.now()-start;if(status)throw Error('invoke failure '+status);const stdout=format(),value=Number(stdout.trim());if(!Number.isFinite(value)||Math.abs(value-cfg.expected_value)>Math.max(1e-12,Math.abs(cfg.expected_value)*1e-12))throw Error('original oracle failure '+stdout);if(i>=0)row.samples.push({elapsed_ms:elapsed,stdout,actual_value:value});await new Promise(r=>setTimeout(r,0));}
 if(row.wasm_sha256!==cfg.wasm_sha256)throw Error('cross-host canonical program SHA mismatch');
 row.raw_operation=stats(row.samples.map(x=>x.elapsed_ms));const compileSamples=[];
 for(let i=0;i<10;i++){const start=performance.now();compiler.compileSource(source,'/browser/'+name+'.vkf');compileSamples.push(performance.now()-start);await new Promise(r=>setTimeout(r,0));}
 row.warm_loaded_frontend_compile={...stats(compileSamples),metric:'compileSource after canonical compiler factory initialization, excludes download and factory startup'};row.passed=true;return row;
};
