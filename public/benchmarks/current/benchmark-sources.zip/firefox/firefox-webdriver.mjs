import {homedir} from 'node:os';
import {spawn} from 'node:child_process';import {mkdir,writeFile} from 'node:fs/promises';
const pause=ms=>new Promise(r=>setTimeout(r,ms));
export async function startFirefox({port=19516,logPath,profileRoot=homedir()+'/snap/firefox/common/vkf-benchmark-profiles'}={}){
 await mkdir(profileRoot,{recursive:true});const driver=spawn('/snap/bin/geckodriver',['--host','127.0.0.1','--port',String(port),'--profile-root',profileRoot,'--allow-system-access'],{stdio:['ignore','pipe','pipe']});let log='';driver.stdout.on('data',b=>log+=b);driver.stderr.on('data',b=>log+=b);
 async function request(method,path,body){const response=await fetch(`http://127.0.0.1:${port}${path}`,{method,headers:{'content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});const j=await response.json();if(j.value?.error)throw new Error(j.value.error+': '+j.value.message);return j.value;}
 let session;
 try{for(let n=0;n<100;n++){try{await request('GET','/status');break;}catch{if(driver.exitCode!==null)throw Error('geckodriver exited '+driver.exitCode+' '+log);await pause(100);}}
 session=await request('POST','/session',{capabilities:{alwaysMatch:{browserName:'firefox','moz:firefoxOptions':{args:['-headless'],binary:'/snap/firefox/current/usr/lib/firefox/firefox',prefs:{'gfx.webrender.software':true,'webgl.disabled':true,'dom.webgpu.enabled':false}}}}});const id=session.sessionId;await request('POST',`/session/${id}/timeouts`,{script:900000,pageLoad:60000,implicit:0});
 return {capabilities:session.capabilities,async navigate(url){return request('POST',`/session/${id}/url`,{url});},async execute(script,args=[]){return request('POST',`/session/${id}/execute/sync`,{script,args});},async executeAsync(script,args=[]){return request('POST',`/session/${id}/execute/async`,{script,args});},async close(){try{await request('DELETE',`/session/${id}`);}finally{driver.kill();if(logPath)await writeFile(logPath,log);}}};
 }catch(e){driver.kill();if(logPath)await writeFile(logPath,log);throw e;}
}
