Default compiler settings;10raw kernel samples per available language. Distinct from optimized primary five workloads. Scalar is the original VKF-only regression.

| Workload | VKF (ms) | C++ (ms) | Rust (ms) | Zig (ms) |
| --- | ---: | ---: | ---: | ---: |
| startup | <0.001 | <0.001 | <0.001 | <0.001 |
| scalar-control-small | 0.064 ± 0.000 | - | - | - |
| spectral-norm-small | 1.520 ± 0.010 | 0.314 ± 0.004 | 0.460 ± 0.007 | 0.458 ± 0.003 |
| spectral-norm-medium | 9.240 ± 0.023 | 1.689 ± 0.006 | 2.852 ± 0.004 | 2.854 ± 0.003 |
| fannkuch-redux-small | 0.854 ± 0.004 | 0.144 ± 0.002 | 0.174 ± 0.002 | 0.187 ± 0.002 |
| fannkuch-redux-medium | 7.900 ± 0.006 | 1.533 ± 0.006 | 1.568 ± 0.012 | 1.672 ± 0.007 |
| n-body-small | 0.230 ± 0.008 | 0.056 ± 0.002 | 0.039 ± 0.002 | 0.078 ± 0.002 |
| n-body-medium | 2.273 ± 0.013 | 0.553 ± 0.003 | 0.390 ± 0.004 | 0.778 ± 0.012 |
| fixed-vector-medium | 0.794 ± 0.017 | 0.130 ± 0.002 | 0.241 ± 0.003 | 0.240 ± 0.002 |
| record-value-medium | 0.758 ± 0.003 | 0.103 ± 0.002 | 0.104 ± 0.003 | 0.103 ± 0.001 |
