# Additional Linux benchmark reproduction

Use the published Linux compiler, Node.js, C++ compiler, Rust and Zig. This derived harness uses the default compiler CLI without optimizer flags. It never rebuilds or substitutes a compiler. Original algorithms remain unchanged; vector/record peer scalar export adapters call original run(75000), using the original volatile/black_box count semantics.

```sh
export PATH=/path/to/zig:$PATH
export VKF_BENCH_DRIVER=/path/to/vektor-flow/bin/vkf
taskset -c 0,1,8,9 node benchmarks/core-comparison/run.mjs --case=startup,scalar-control-small,spectral-norm-small,spectral-norm-medium,fannkuch-redux-small,fannkuch-redux-medium,n-body-small,n-body-medium --language=vkf,cpp,rust,zig --compile-runs=10 --compile-warmups=1 --runs=10 --warmups=5 --process-runs=10 --process-warmups=1 --function-landscape-runs=0 --max-cores=2 --output=additional-eight
taskset -c 0,1,8,9 node benchmarks/core-comparison/run.mjs --case=fixed-vector-medium,record-value-medium --language=vkf,cpp,rust,zig --compile-runs=10 --compile-warmups=1 --runs=10 --warmups=5 --process-runs=10 --process-warmups=1 --function-landscape-runs=0 --max-cores=2 --output=additional-two
```

Choose available CPU IDs on your own host. Raw kernel timings exclude compilation and process startup; those have separate metrics. Completed workload groups retain checkpoint arrays. Scalar is the original VKF-only regression. Startup is below0.001ms; its ratio would be dominated by measurement overhead. Peer compile and all process timings retain counts and aggregates only; VKF compile receipts and all raw kernel samples retain individual values. Reproduction produces fresh measurements rather than identical host timings.
