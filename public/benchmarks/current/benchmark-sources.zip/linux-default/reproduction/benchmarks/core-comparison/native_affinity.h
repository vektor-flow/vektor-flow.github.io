#ifndef VKF_BENCHMARK_NATIVE_AFFINITY_H
#define VKF_BENCHMARK_NATIVE_AFFINITY_H

#include <stdio.h>

typedef struct VkfAffinitySelection {
    int cpu[2];
    int count;
} VkfAffinitySelection;

static VkfAffinitySelection vkf_select_performance_cpus(int requested_width) {
    VkfAffinitySelection result = {{-1, -1}, 0};
    if (requested_width < 1 || requested_width > 2) return result;
#ifdef _WIN32
    typedef struct VkfCpuCandidate {
        int cpu;
        unsigned char core;
        unsigned char efficiency;
    } VkfCpuCandidate;
    DWORD_PTR process_mask = 0;
    DWORD_PTR system_mask = 0;
    if (!GetProcessAffinityMask(GetCurrentProcess(), &process_mask, &system_mask) ||
        process_mask == 0) return result;

    VkfCpuCandidate candidates[sizeof(DWORD_PTR) * 8u];
    int candidate_count = 0;
    ULONG bytes = 0;
    GetSystemCpuSetInformation(NULL, 0, &bytes, GetCurrentProcess(), 0);
    SYSTEM_CPU_SET_INFORMATION *sets = bytes == 0
        ? NULL : (SYSTEM_CPU_SET_INFORMATION *)malloc(bytes);
    if (sets != NULL && GetSystemCpuSetInformation(
            sets, bytes, &bytes, GetCurrentProcess(), 0)) {
        unsigned char *cursor = (unsigned char *)sets;
        unsigned char *end = cursor + bytes;
        while (cursor + sizeof(SYSTEM_CPU_SET_INFORMATION) <= end) {
            SYSTEM_CPU_SET_INFORMATION *set =
                (SYSTEM_CPU_SET_INFORMATION *)cursor;
            if (set->Size == 0 || cursor + set->Size > end) break;
            if (set->Type == CpuSetInformation && set->CpuSet.Group == 0 &&
                set->CpuSet.LogicalProcessorIndex < sizeof(DWORD_PTR) * 8u) {
                const int cpu = (int)set->CpuSet.LogicalProcessorIndex;
                if ((process_mask & (((DWORD_PTR)1) << cpu)) != 0) {
                    candidates[candidate_count].cpu = cpu;
                    candidates[candidate_count].core = set->CpuSet.CoreIndex;
                    candidates[candidate_count].efficiency =
                        set->CpuSet.EfficiencyClass;
                    ++candidate_count;
                }
            }
            cursor += set->Size;
        }
    }
    free(sets);
    if (candidate_count == 0) {
        for (int cpu = 0; cpu < (int)(sizeof(DWORD_PTR) * 8u); ++cpu) {
            if ((process_mask & (((DWORD_PTR)1) << cpu)) == 0) continue;
            candidates[candidate_count++] = (VkfCpuCandidate){
                cpu, (unsigned char)cpu, 0
            };
        }
    }
    for (int left = 0; left < candidate_count; ++left) {
        for (int right = left + 1; right < candidate_count; ++right) {
            if (candidates[right].efficiency > candidates[left].efficiency ||
                (candidates[right].efficiency == candidates[left].efficiency &&
                 (candidates[right].core > candidates[left].core ||
                  (candidates[right].core == candidates[left].core &&
                   candidates[right].cpu < candidates[left].cpu)))) {
                const VkfCpuCandidate temporary = candidates[left];
                candidates[left] = candidates[right];
                candidates[right] = temporary;
            }
        }
    }
    if (candidate_count > 0) result.cpu[result.count++] = candidates[0].cpu;
    for (int index = 1;
         index < candidate_count && result.count < requested_width; ++index) {
        if (candidates[index].core != candidates[0].core) {
            result.cpu[result.count++] = candidates[index].cpu;
        }
    }
    for (int index = 1;
         index < candidate_count && result.count < requested_width; ++index) {
        if (candidates[index].cpu != result.cpu[0]) {
            result.cpu[result.count++] = candidates[index].cpu;
        }
    }
#elif defined(__linux__)
    typedef struct VkfLinuxCpuCandidate {
        int cpu;
        int package;
        int core;
    } VkfLinuxCpuCandidate;
    cpu_set_t allowed;
    CPU_ZERO(&allowed);
    if (sched_getaffinity(0, sizeof(allowed), &allowed) != 0) return result;

    VkfLinuxCpuCandidate candidates[CPU_SETSIZE];
    int candidate_count = 0;
    for (int cpu = 0; cpu < CPU_SETSIZE; ++cpu) {
        if (!CPU_ISSET(cpu, &allowed)) continue;
        VkfLinuxCpuCandidate candidate = {cpu, 0, cpu};
        char path[128];
        snprintf(path, sizeof(path),
                 "/sys/devices/system/cpu/cpu%d/topology/physical_package_id",
                 cpu);
        FILE *topology = fopen(path, "r");
        if (topology != NULL) {
            if (fscanf(topology, "%d", &candidate.package) != 1)
                candidate.package = 0;
            fclose(topology);
        }
        snprintf(path, sizeof(path),
                 "/sys/devices/system/cpu/cpu%d/topology/core_id", cpu);
        topology = fopen(path, "r");
        if (topology != NULL) {
            if (fscanf(topology, "%d", &candidate.core) != 1)
                candidate.core = cpu;
            fclose(topology);
        }
        candidates[candidate_count++] = candidate;
    }
    if (candidate_count > 0) {
        const VkfLinuxCpuCandidate first = candidates[0];
        result.cpu[result.count++] = first.cpu;
        for (int index = 1;
             index < candidate_count && result.count < requested_width; ++index) {
            const VkfLinuxCpuCandidate candidate = candidates[index];
            if (candidate.package != first.package ||
                candidate.core != first.core) {
                result.cpu[result.count++] = candidate.cpu;
            }
        }
        for (int index = 1;
             index < candidate_count && result.count < requested_width; ++index) {
            if (candidates[index].cpu != first.cpu)
                result.cpu[result.count++] = candidates[index].cpu;
        }
    }
#else
    (void)requested_width;
#endif
    return result;
}

#endif
