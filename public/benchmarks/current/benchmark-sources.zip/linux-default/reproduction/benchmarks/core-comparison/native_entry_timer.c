#ifndef _WIN32
#define _GNU_SOURCE
#endif
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "../../compiler/native/vkf_runtime_abi.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <pthread.h>
#include <sys/mman.h>
#include <unistd.h>
#include <time.h>
#ifdef __linux__
#include <sched.h>
#endif
#endif
#include "native_affinity.h"

typedef struct VkfRuntimeV6 {
    double (*power_f64)(double, double);
    double (*remainder_f64)(double, double);
    double (*floor_f64)(double);
    double (*ln_f64)(double);
    double (*sin_f64)(double);
    double (*cos_f64)(double);
    double (*exp_f64)(double);
    const unsigned char *string_data;
    void *(*allocate)(size_t);
    void (*release)(void *);
    void (*abort_process)(void);
    void *reserved[VKF_RUNTIME_SLOT_COUNT - 11u];
#ifdef _WIN32
    HANDLE (WINAPI *thread_create)(LPSECURITY_ATTRIBUTES, SIZE_T,
        LPTHREAD_START_ROUTINE, LPVOID, DWORD, LPDWORD);
    DWORD (WINAPI *thread_join)(HANDLE, DWORD);
    BOOL (WINAPI *thread_close)(HANDLE);
#else
    int (*thread_create)(pthread_t *, const pthread_attr_t *,
        void *(*)(void *), void *);
    int (*thread_join)(pthread_t, void **);
    void (*thread_close)(void *);
#endif
} VkfRuntimeV6;

typedef char vkf_runtime_v6_must_match_shared_slot_contract[
    sizeof(VkfRuntimeV6) ==
        (VKF_RUNTIME_SLOT_COUNT + VKF_RUNTIME_PRIVATE_THREAD_SLOT_COUNT) *
            sizeof(void *) ? 1 : -1
];

typedef double (*VkfEntry)(const VkfRuntimeV6 *);

static int parallel_width = 1;
static int worker_cpu = -1;
static int threads_created = 0;
static int threads_joined = 0;
static int thread_handles_closed = 0;

#ifdef _WIN32
static HANDLE WINAPI measured_thread_create(
    LPSECURITY_ATTRIBUTES attributes,
    SIZE_T stack_size,
    LPTHREAD_START_ROUTINE start,
    LPVOID context,
    DWORD flags,
    LPDWORD thread_id
) {
    HANDLE thread = CreateThread(
        attributes, stack_size, start, context,
        flags | CREATE_SUSPENDED, thread_id
    );
    if (thread == NULL) return NULL;
    if (worker_cpu < 0 ||
        SetThreadAffinityMask(thread, ((DWORD_PTR)1) << worker_cpu) == 0 ||
        ResumeThread(thread) == (DWORD)-1) {
        CloseHandle(thread);
        return NULL;
    }
    ++threads_created;
    return thread;
}

static DWORD WINAPI measured_thread_join(HANDLE thread, DWORD timeout) {
    const DWORD result = WaitForSingleObject(thread, timeout);
    if (result == WAIT_OBJECT_0) ++threads_joined;
    return result;
}

static BOOL WINAPI measured_thread_close(HANDLE thread) {
    const BOOL result = CloseHandle(thread);
    if (result) ++thread_handles_closed;
    return result;
}
#else
static int measured_thread_create(
    pthread_t *thread,
    const pthread_attr_t *attributes,
    void *(*start)(void *),
    void *context
) {
    int result = 0;
#ifdef __linux__
    pthread_attr_t pinned;
    if (worker_cpu < 0 || pthread_attr_init(&pinned) != 0) return EINVAL;
    cpu_set_t selected;
    CPU_ZERO(&selected);
    CPU_SET(worker_cpu, &selected);
    result = pthread_attr_setaffinity_np(&pinned, sizeof(selected), &selected);
    if (result == 0) result = pthread_create(thread, &pinned, start, context);
    pthread_attr_destroy(&pinned);
#else
    result = pthread_create(thread, attributes, start, context);
#endif
    if (result == 0) ++threads_created;
    return result;
}

static int measured_thread_join(pthread_t thread, void **result_value) {
    const int result = pthread_join(thread, result_value);
    if (result == 0) {
        ++threads_joined;
        ++thread_handles_closed;
    }
    return result;
}

static void measured_thread_close(void *unused) { (void)unused; }
#endif

static int compare_double(const void *left, const void *right) {
    const double a = *(const double *)left;
    const double b = *(const double *)right;
    return (a > b) - (a < b);
}

static double monotonic_ms(void) {
#ifdef _WIN32
    LARGE_INTEGER frequency;
    LARGE_INTEGER now;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&now);
    return (double)now.QuadPart * 1000.0 / (double)frequency.QuadPart;
#else
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
        perror("clock_gettime");
        exit(2);
    }
    return (double)now.tv_sec * 1000.0 + (double)now.tv_nsec / 1000000.0;
#endif
}

static int configure_affinity(int requested_width) {
#ifdef _WIN32
    const VkfAffinitySelection selected =
        vkf_select_performance_cpus(requested_width);
    if (selected.count < requested_width) return -1;
    worker_cpu = requested_width == 2 ? selected.cpu[1] : -1;
    return SetThreadAffinityMask(
        GetCurrentThread(), ((DWORD_PTR)1) << selected.cpu[0]
    ) != 0 ? selected.cpu[0] : -1;
#elif defined(__linux__)
    const VkfAffinitySelection selected =
        vkf_select_performance_cpus(requested_width);
    if (selected.count < requested_width) return -1;
    worker_cpu = requested_width == 2 ? selected.cpu[1] : -1;
    cpu_set_t pinned;
    CPU_ZERO(&pinned);
    CPU_SET(selected.cpu[0], &pinned);
    return sched_setaffinity(0, sizeof(pinned), &pinned) == 0
        ? selected.cpu[0] : -1;
#else
    if (requested_width == 2 && sysconf(_SC_NPROCESSORS_ONLN) < 2) return -1;
    return -1;
#endif
}

static int invoke(VkfEntry entry, const VkfRuntimeV6 *runtime, double *result) {
    threads_created = 0;
    threads_joined = 0;
    thread_handles_closed = 0;
    *result = entry(runtime);
    return parallel_width != 2 ||
        (threads_created == 1 && threads_joined == 1 &&
         thread_handles_closed == 1);
}

int main(int argc, char **argv) {
    if (argc != 4 && argc != 5 && argc != 6) {
        fprintf(stderr, "usage: native_entry_timer code.bin [data.bin] warmups runs [parallel_width]\n");
        return 1;
    }
    const int parallel_argument = argc == 6 ? 5 : 0;
    parallel_width = parallel_argument ? atoi(argv[parallel_argument]) : 1;
    const int data_argument = argc >= 5 ? 2 : 0;
    const int warmups = atoi(argv[parallel_argument ? 3 : argc - 2]);
    const int runs = atoi(argv[parallel_argument ? 4 : argc - 1]);
    if (parallel_width != 1 && parallel_width != 2) return 1;
    if (warmups < 0 || runs < 2) return 1;
    const int affinity_cpu = configure_affinity(parallel_width);
#if defined(_WIN32) || defined(__linux__)
    if (affinity_cpu < 0) return 2;
#endif

    FILE *input = fopen(argv[1], "rb");
    if (input == NULL || fseek(input, 0, SEEK_END) != 0) return 2;
    const long size = ftell(input);
    if (size <= 0 || fseek(input, 0, SEEK_SET) != 0) return 2;
    void *memory =
#ifdef _WIN32
        VirtualAlloc(NULL, (size_t)size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (memory == NULL) return 2;
#else
        mmap(NULL, (size_t)size, PROT_READ | PROT_WRITE,
             MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (memory == MAP_FAILED) {
        perror("mmap");
        return 2;
    }
#endif
    if (fread(memory, 1, (size_t)size, input) != (size_t)size) return 2;
    fclose(input);
#ifdef _WIN32
    DWORD old_protection = 0;
    if (!VirtualProtect(memory, (size_t)size, PAGE_EXECUTE_READ, &old_protection)) return 2;
    FlushInstructionCache(GetCurrentProcess(), memory, (size_t)size);
#else
    if (mprotect(memory, (size_t)size, PROT_READ | PROT_EXEC) != 0) {
        perror("mprotect");
        return 2;
    }
#endif

    unsigned char *literal_data = NULL;
    if (data_argument != 0) {
        FILE *data_input = fopen(argv[data_argument], "rb");
        if (data_input == NULL || fseek(data_input, 0, SEEK_END) != 0) return 2;
        const long data_size = ftell(data_input);
        if (data_size < 0 || fseek(data_input, 0, SEEK_SET) != 0) return 2;
        literal_data = malloc(data_size == 0 ? 1u : (size_t)data_size);
        if (literal_data == NULL) return 2;
        if (data_size > 0 &&
            fread(literal_data, 1, (size_t)data_size, data_input) != (size_t)data_size) return 2;
        fclose(data_input);
    }

    const VkfRuntimeV6 runtime = {
        pow, fmod, floor, log, sin, cos, exp, literal_data, malloc, free, abort,
        {0}, measured_thread_create, measured_thread_join, measured_thread_close
    };
    VkfEntry entry = (VkfEntry)memory;
    volatile double result = 0.0;
    for (int index = 0; index < warmups; ++index) {
        double value = 0.0;
        if (!invoke(entry, &runtime, &value)) return 3;
        result = value;
    }

    double *samples = malloc((size_t)runs * sizeof(double));
    double *sample_values = malloc((size_t)runs * sizeof(double));
    double *ordered_samples = malloc((size_t)runs * sizeof(double));
    if (samples == NULL || sample_values == NULL || ordered_samples == NULL) return 2;
    double sum = 0.0;
    for (int index = 0; index < runs; ++index) {
        const double started = monotonic_ms();
        double value = 0.0;
        if (!invoke(entry, &runtime, &value)) return 3;
        result = value;
        const double finished = monotonic_ms();
        samples[index] = finished - started;
        ordered_samples[index] = samples[index];
        sample_values[index] = value;
        sum += samples[index];
    }
    const double mean = sum / runs;
    double squared_deviation = 0.0;
    for (int index = 0; index < runs; ++index) {
        const double delta = samples[index] - mean;
        squared_deviation += delta * delta;
    }
    const double stddev = sqrt(squared_deviation / (runs - 1));
    qsort(samples, (size_t)runs, sizeof(double), compare_double);
    const double median = runs % 2 == 0
        ? (samples[runs / 2 - 1] + samples[runs / 2]) * 0.5
        : samples[runs / 2];
    const int p95_index = (int)ceil(runs * 0.95) - 1;
    printf(
        "{\"runs\":%d,\"affinity_cpu\":%d,\"mean_ms\":%.6f,\"stddev_ms\":%.6f,"
        "\"median_ms\":%.6f,\"p95_ms\":%.6f,\"min_ms\":%.6f,\"max_ms\":%.6f,"
        "\"result\":%.17g,\"parallel_width\":%d,\"threads_created\":%d,"
        "\"threads_joined\":%d,\"thread_handles_closed\":%d,\"samples_ms\":[",
        runs, affinity_cpu, mean, stddev, median, samples[p95_index], samples[0],
        samples[runs - 1], result, parallel_width, threads_created,
        threads_joined, thread_handles_closed);
    for (int index = 0; index < runs; ++index) {
        if (index != 0) putchar(',');
        printf("%.6f", ordered_samples[index]);
    }
    fputs("],\"sample_values\":[", stdout);
    for (int index = 0; index < runs; ++index) {
        if (index != 0) putchar(',');
        printf("%.17g", sample_values[index]);
    }
    fputs("]}\n", stdout);
    free(samples);
    free(sample_values);
    free(ordered_samples);
    free(literal_data);
#ifdef _WIN32
    VirtualFree(memory, 0, MEM_RELEASE);
#else
    munmap(memory, (size_t)size);
#endif
    return 0;
}
