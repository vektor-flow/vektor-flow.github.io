#pragma once

// C-compatible constants shared by generated code, executable wrappers, and
// raw-entry benchmark/runtime adapters. Private thread callbacks immediately
// follow the public runtime table and never consume public ABI slots.
#define VKF_RUNTIME_SLOT_COUNT 84u
#define VKF_RUNTIME_OUTPUT_BASE 1024u
#define VKF_RUNTIME_PRIVATE_THREAD_SLOT_COUNT 3u
