10 operation-time samples per original workload; every original numeric oracle passes. Default mask-0. Compilation and process startup excluded. Peer results unavailable (-).

| Workload | VKF (ms) | SymEngine | SymPy | Symbolics.jl |
| --- | ---: | ---: | ---: | ---: |
| expand1 | 44801.898 ± 70.529 | - | - | - |
| expand2 | 316.447 ± 1.650 | - | - | - |
| add1 | 0.462 ± 0.015 | - | - | - |
| series | 3.053 ± 0.027 | - | - | - |
