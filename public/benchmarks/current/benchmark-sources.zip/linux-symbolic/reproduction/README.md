# Linux symbolic reproduction

Use the current published Linux compiler and Node.js. Every program is compiled by that compiler; no external engine helper or older compiler is substituted. The four original output oracles remain enforced.

```sh
taskset -c 0,1,8,9 node benchmarks/symbolic-comparison/run.mjs --compiler=/path/to/vektor-flow/bin/vkf --kernels=expand1,expand2,add1,series --languages=vkf --runs=10 --timeout-ms=60000 --optimizer-policy=mask-0 --enforce-relative-gate=false --output=results/linux-symbolic.json
```

Select available CPU IDs for your host. The program prints operation milliseconds from its original monotonic clock brackets and then its numerical oracle. Operation timing excludes compilation, input/expression setup and process startup. No process-wall or compile samples are claimed here. Peer libraries were unavailable, so relative performance gates and ratios are inapplicable; exact numerical oracles remain mandatory. Largest expansion took roughly45seconds per invocation on the measured machine. Each attempt has a60second process deadline; do not add a shorter whole-suite supervisor deadline. Completed operation attempts and per-kernel results retain durable raw checkpoints. Source hashes and native artifact hashes are recorded before temporary artifact cleanup. Reproduction yields fresh host measurements.
