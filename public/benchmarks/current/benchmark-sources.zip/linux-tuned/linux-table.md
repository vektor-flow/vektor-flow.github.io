Linux, ten raw-kernel samples per lane. Lower ratio means VKF is faster.

| Workload | VKF ms ± stddev | VKF/C++ | VKF/Rust | VKF/Zig |
| --- | ---: | ---: | ---: | ---: |
| spectral-norm-large | 36.444 ± 0.020 | 5.299× | 3.191× | 3.190× |
| fannkuch-redux-large | 787.273 ± 1.116 | 5.523× | 4.690× | 4.299× |
| n-body-large | 36.290 ± 0.023 | 3.270× | 4.649× | 2.340× |
| combined-kernels-large | 394.252 ± 2.005 | 2.278× | 3.708× | 4.209× |
| combined-kernels-parallel-large | 286.948 ± 0.259 | 1.661× | 2.704× | 3.073× |
