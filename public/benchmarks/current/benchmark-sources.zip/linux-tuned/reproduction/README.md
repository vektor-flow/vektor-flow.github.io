# Linux benchmark reproduction

Use the current published Linux compiler, Node.js, C++ compiler, Rust and Zig. This harness requires an explicit compiler path and never rebuilds or substitutes a VKF compiler. Sources are unchanged measured inputs.

Run on two physical cores (CPU IDs below match the measured host; select suitable distinct cores on your machine):

```sh
export PATH=/path/to/zig:$PATH
export VKF_BENCH_DRIVER=/path/to/vektor-flow/bin/vkf
taskset -c 0,1,8,9 node benchmarks/core-comparison/run.mjs --case=spectral-norm-large,fannkuch-redux-large,n-body-large,combined-kernels-large,combined-kernels-parallel-large --language=vkf,cpp,rust,zig --compile-runs=10 --compile-warmups=1 --runs=10 --warmups=5 --process-runs=10 --process-warmups=1 --function-landscape-runs=0 --max-cores=2 --output=local
```

Raw kernel timing excludes compilation and process startup. Compile wall/internal times and fresh-process runtime are separate. Explicit automatic optimization is calibrated outside measured compilation and uses its retained cache; these compile timings describe that configuration, not default CLI latency. Parallel VKF must demonstrate two physical cores and a created/joined/closed worker before its row is accepted; peer combined kernels run serially.

The JSON retains all raw kernel samples. Peer compile and process timing arrays are not retained by this harness; their sample counts and aggregates remain available. Reproduction yields fresh measurements, not a promise of identical host timings.
