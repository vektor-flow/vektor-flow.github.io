Vektor Flow — Linux x86_64 compiler

Run without installation:
  ./bin/vkf samples/index-001.vkf
  ./bin/vkf -e '::1+2'
  ./bin/vkf -b program.vkf -o program
  ./bin/vkf --version

Install for the current user:
  ./install.sh

The installer adds a vkf link under ~/.local/bin. Put that directory on PATH.
The matching standard library is included and resolved from the bundle.

This is a partial compiler release. The console examples supplied here execute
with the native compiler. UI examples currently run in the website playground;
native UI application packaging is incomplete. Full Section 0 acceptance is
incomplete. Windows and macOS packages are not provided.

Third-party and upstream notices are retained under third-party/.
