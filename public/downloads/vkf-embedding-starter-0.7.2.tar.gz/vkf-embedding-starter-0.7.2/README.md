# Vektor Flow 0.7.2 HTML embedding starter

Run python3 -m http.server 8000 in this folder, then open
http://localhost:8000/embed-example.html. Use HTTPS on a public host.
Keep all relative paths and third-party notices. The service worker can
reload once to establish browser isolation. This package uses the
published incomplete 0.7.2 compiler, not a stable 0.7.5 release.
The form compiles and runs VKF in a local Web Worker; it does not use
a calculation server. See STARTER-MANIFEST.json for file hashes.
