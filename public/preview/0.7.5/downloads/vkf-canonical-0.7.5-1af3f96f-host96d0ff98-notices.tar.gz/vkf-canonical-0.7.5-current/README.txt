Vektor Flow 0.7.5 — Physics-owned SI catalog and compatibility imports.

The SI catalog is authored by :.physics.units; :.units and :.units.si use normal module forwarding.
Library source804892b62f3dd938fd67d820f322a72c0c1ed96c. Fresh WASM binding 1af3f96fb8d66e610a1ccad91b2030afda03acf2987f3db7d2f145753dc011b5. Native binary binding 305da34c347e2d75f5216347d7e5b22ebe0fe4e04ff3588b552345a7b284a352 identifies the unchanged selected compiler binary; installed library source is separately804892b, not a C++ rebuild. Formatter9de785 unchanged; current Node host96d preserved.

Node >=22, from this extracted directory:
  node package-tools/cli.mjs install /absolute/project --compiler ./compiler.mjs
  node package-tools/cli.mjs run /absolute/project --compiler ./compiler.mjs
  node package-tools/cli.mjs compile /absolute/project --compiler ./compiler.mjs --out /absolute/output
Native extracted package:
  ./bin/vkf --source-binding
  ./bin/vkf /absolute/program.vkf
  ./bin/vkf --diagnostics -b /absolute/program.vkf -o /absolute/program

Exact scoped correctness/archives are recorded in VERIFICATION.json. No whole SDK, full language/platform, GPU world, all-font/LaTeX, benchmark or comparative timing qualification. Existing version0.7.5 unchanged.
