Current 0.7.5 canonical compiler + independent formatter + full package-tools/helper closure

Exact compiler source 74cfd17c3d299069f013c828b27b3581d0c9f197; host 63553cc03124469cb29c73c04b99d7ce65b7a335; binding ffcaeaae67079c714583d5487f3452a9ed4107abf14204a512f647400473c71f.

From the extracted package directory, with Node >=22:
  node package-tools/cli.mjs run /absolute/project --compiler ./compiler.mjs
  node package-tools/cli.mjs compile /absolute/project --compiler ./compiler.mjs --out /absolute/output
  node package-tools/cli.mjs install /absolute/project --compiler ./compiler.mjs

The same runner maintains the single vkf.lock. Console-only guest run is supported; retained UI/concurrent programs use the normal retained browser host. This archive is the complete19-file canonical closure, not a package-tools-only install. Browser owner integration remains separately staged in the browser-host directory in the actual evidence root.

Current browser parameter/widget/editor and native20/address checks passed in their declared scopes. No complete language/platform/SDK/GPU/standards/benchmark claim. Those broader scopes are not additional release gates. Existing required-scale correctness remains applicable. Private central owner-policy deployment blocks shared uploading; it does not negate the tested local/browser package correctness.

The Node package publisher includes the reviewed host96d0ff98 delta. Shared source proposals use protected public main, trusted-maintainer current-head inspection and expected-SHA PR merge. See OWNER-HOST.json; original renderer qualification remains incomplete.
