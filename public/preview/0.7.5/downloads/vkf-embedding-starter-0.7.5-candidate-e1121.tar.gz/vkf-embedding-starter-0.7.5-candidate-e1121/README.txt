VKF 0.7.5 private candidate, incomplete and not a stable release.
Run python3 -m http.server 8000 in this directory, then open http://localhost:8000/embed-example.html.
The isolation service worker may reload once. Preserve runtime paths and notices.
See STARTER-MANIFEST.json and actual qualification receipts for exact scope.
