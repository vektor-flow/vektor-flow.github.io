Run python3 -m http.server 8000, then open http://localhost:8000/embed-example.html. The existing service worker establishes browser isolation when necessary. Keep relative paths and third-party notices.
EXPERIMENTAL 0.7.5 browser / Node ESM candidate
Compiler-owned evaluated-output formatter binding 3a6a07dd411a94039577b4bc1dae08be6801b41c8fc272ec2252fdcded679e03.
Frontend / guest VM binding 4b2eaa19fa54dcfbf165dc3da18571b3efa1363606b8296a0a1277ba1b204cef.
Current genuine five-million-point packet, all fifty million vertex channels and five million indices, static retained GPU presentation, view and ordinary color packet were checked on Linux NVIDIA Pascal.
Finite quadratic history, pan/zoom/retarget and source-edit plot checks are scoped evidence, not full language qualification.
The required native ten-thousand-label current-component output and full nonlinear GPU world remain unverified/incomplete. No stable 0.7.5, full-native or all-platform qualification. Timings are informational.
See ../../verification/e1615-current-renderer-queue.json for exact source, artifacts, failures, scope and endpoints.

Current native-label entry and scoped checks: verification/e1619-current-native10000.json.

Current native mesh scoped quality: verification/e1623-current-native-mesh.json.

Current supported embedding checks: 57/57 unchanged canonical browser source/output/scene-byte cases; normal Node ESM control retained by exact unchanged compiler/formatter identity. Full stable 0.7.5 and Linux compiler SDK are not qualified. See verification/e1625-current-qualification.json.
