/**
 * vf-runtime-scene.js — scene mount/apply adapter for the runtime shell.
 */
(function(global) {
  "use strict";

  if (global.VfRuntimeScene) { return; }

  function countExitTrackedFrames(layer) {
    if (!layer || !layer.querySelectorAll) { return 0; }
    var nodes = layer.querySelectorAll(".vf-frame");
    var count = 0;
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node || !node.dataset) { continue; }
      if (node.dataset.vfExitCounted === "false") { continue; }
      count += 1;
    }
    return count;
  }

  function createAdapter(options) {
    options = options || {};
    var createRuntimeDependencies = options.createRuntimeDependencies || function() { return {}; };
    var runtimeLog = options.runtimeLog || function() {};
    var getLayer = options.getLayer || function() { return null; };
    var displayRefresh = options.displayRefresh || function() {};
    var isLegacyFallbackActive = options.isLegacyFallbackActive || function() { return false; };
    var livePanelsById = Object.create(null);
    var lastInternalHtmlPatchSequence = 0;

    function runtimeFail(message) {
      var text = String(message || "runtime scene failure");
      try { runtimeLog("error", text); } catch (_) {}
      throw new Error(text);
    }

    function reapplySpecRect(panel, spec, phase) {
      try {
        applySpecRectToPanel(panel, spec);
      } catch (error) {
        runtimeFail(
          "applySceneCommands: layout reapply failed during " +
          String(phase || "layout") +
          ": " +
          (error && error.message ? error.message : String(error))
        );
      }
    }

    function syncNativeLayout() {
      var deps = createRuntimeDependencies();
      var layer = getLayer();
      if (!layer || !deps.frame || !deps.frame.postNativeHostLayout) { return; }
      deps.frame.postNativeHostLayout(layer, { stageAlpha: 0 });
    }

    function applyInternalHtmlPatchPacket(packet) {
      var patch = packet && packet.payload && packet.payload.__vf_internal_retained_html_patch;
      var owner = patch && patch.owner;
      var sequence = Number(packet && packet.seq);
      if (!patch || patch.version !== 1 || !owner ||
          !Number.isInteger(sequence) || sequence <= lastInternalHtmlPatchSequence) {
        runtimeFail("applyInternalHtmlPatchPacket: malformed or stale private patch packet");
      }
      var ownerRoot = null;
      if (owner.kind === "frame") {
        var panel = livePanelsById[String(owner.id || "")];
        ownerRoot = panel && panel.root;
      } else if (owner.kind === "display") {
        var layer = getLayer();
        var displayId = layer && layer.dataset
          ? String(layer.dataset.vfDisplayId || layer.id || "")
          : "";
        if (displayId === String(owner.id || "")) { ownerRoot = layer; }
      }
      if (!ownerRoot || !global.VfHtmlComponents || !global.VfHtmlComponents.__internal ||
          typeof global.VfHtmlComponents.__internal.applyPatch !== "function") {
        runtimeFail("applyInternalHtmlPatchPacket: retained owner is unavailable");
      }
      global.VfHtmlComponents.__internal.applyPatch(ownerRoot, patch);
      lastInternalHtmlPatchSequence = sequence;
    }

    function applySpecRectToPanel(panel, spec) {
      var deps = createRuntimeDependencies();
      var frame = deps.frame;
      if (!frame) { return; }
      var r = spec && spec.rect;
      var anch = spec && spec.anchor != null ? String(spec.anchor) : "tl";
      var x = r && typeof r.x === "number" ? r.x : 0;
      var y = r && typeof r.y === "number" ? r.y : 0;
      var w = r && typeof r.w === "number" ? r.w : 1;
      var h = r && typeof r.h === "number" ? r.h : 1;
      function clamp01(v) {
        return Math.max(0, Math.min(1, v));
      }
      x = clamp01(x);
      y = clamp01(y);
      w = clamp01(w);
      h = clamp01(h);
      var k = frame.normalizeDockLocationKey ? frame.normalizeDockLocationKey(anch) : "tl";
      var parentEl = panel.root.offsetParent || panel.root.parentElement || panel.root;
      var isNestedLayer = !!(parentEl && parentEl.classList && parentEl.classList.contains("vf-frame__overlay"));
      var cs = global.getComputedStyle ? global.getComputedStyle(parentEl) : null;
      var padL = isNestedLayer ? 0 : Math.max(0, Math.round(parseFloat(cs && cs.paddingLeft ? cs.paddingLeft : "0") || 0));
      var padR = isNestedLayer ? 0 : Math.max(0, Math.round(parseFloat(cs && cs.paddingRight ? cs.paddingRight : "0") || 0));
      var padT = isNestedLayer ? 0 : Math.max(0, Math.round(parseFloat(cs && cs.paddingTop ? cs.paddingTop : "0") || 0));
      var padB = isNestedLayer ? 0 : Math.max(0, Math.round(parseFloat(cs && cs.paddingBottom ? cs.paddingBottom : "0") || 0));
      var parentW = parentEl && parentEl.clientWidth ? parentEl.clientWidth : 1;
      var parentH = parentEl && parentEl.clientHeight ? parentEl.clientHeight : 1;
      var availW = Math.max(1, parentW - padL - padR);
      var availH = Math.max(1, parentH - padT - padB);
      var fw = Math.max(1, Math.round(w * availW));
      var fh = Math.max(1, Math.round(h * availH));
      var aspect = String(
        (panel && panel.root && panel.root.dataset && panel.root.dataset.vfAspect) ||
        (spec && spec.aspect) ||
        ""
      ).trim().toLowerCase();
      if (aspect === "equal") {
        var rootEl = panel && panel.root ? panel.root : null;
        var bodyEl = panel && panel.body ? panel.body : null;
        var headerEl = rootEl ? rootEl.querySelector(".vf-frame__header") : null;
        var headerH = 34;
        var chromeExtra = 2;
        if (headerEl && typeof headerEl.getBoundingClientRect === "function") {
          headerH = Math.max(1, Math.round(headerEl.getBoundingClientRect().height || 34));
        }
        if (rootEl && bodyEl &&
            typeof rootEl.getBoundingClientRect === "function" &&
            typeof bodyEl.getBoundingClientRect === "function") {
          var rootRect = rootEl.getBoundingClientRect();
          var bodyRect = bodyEl.getBoundingClientRect();
          var measuredChrome = Math.round((rootRect.height || 0) - (bodyRect.height || 0));
          if (measuredChrome > 0) {
            headerH = measuredChrome;
            chromeExtra = 0;
          }
        }
        var bodyFit = Math.max(1, Math.min(fw, Math.max(1, fh - headerH - chromeExtra)));
        fw = bodyFit;
        fh = bodyFit + headerH + chromeExtra;
      }
      var v = k.charAt(0);
      var hz = k.charAt(1);
      var ax = padL + x * availW;
      var ay = padT + y * availH;
      if (hz === "r") { ax = padL + (1 - x) * availW; }
      if (v === "b") { ay = padT + (1 - y) * availH; }
      var ox = hz === "r" ? fw : (hz === "c" ? fw * 0.5 : 0);
      var oy = v === "b" ? fh : (v === "c" ? fh * 0.5 : 0);
      var leftPx = Math.round(ax - ox);
      var topPx = Math.round(ay - oy);
      var minL = padL;
      var minT = padT;
      var maxL = Math.max(minL, parentW - padR - fw);
      var maxT = Math.max(minT, parentH - padB - fh);
      leftPx = Math.min(maxL, Math.max(minL, leftPx));
      topPx = Math.min(maxT, Math.max(minT, topPx));
      var root = panel.root;
      root.dataset.vfAnchor = k;
      root.style.left = leftPx + "px";
      root.style.top = topPx + "px";
      root.style.width = fw + "px";
      root.style.height = fh + "px";
      root.style.right = "auto";
      root.style.bottom = "auto";
      root.classList.add("vf-frame--user-sized");
      if (typeof panel.syncPointerPassThrough === "function") {
        panel.syncPointerPassThrough();
      }
      if (typeof panel.renderTitle === "function") {
        panel.renderTitle();
      }
    }

  function postExitToHost() {
    var wv = global.chrome && global.chrome.webview;
    if (wv && typeof wv.postMessage === "function") {
      wv.postMessage({ type: "close" });
    }
  }

  function runtimeAllowsHostExit() {
    try {
      if (typeof document === "undefined" || !document || !document.body) {
        return !!(global.chrome && global.chrome.webview);
      }
      var attr = document.body.getAttribute("data-vf-allow-host-exit");
      if (attr === "false") { return false; }
      if (attr === "true") { return true; }
      return !!(global.chrome && global.chrome.webview);
    } catch (_) {
      return false;
    }
  }

  function runtimeHasStandaloneDisplayContent() {
    try {
      return !!global.__vfHasStandaloneDisplayContent;
    } catch (_) {
      return false;
    }
  }

  function runtimeSceneDeclaresFrames() {
    try {
      return Number(global.__vfSceneDeclaredFrameCount || 0) > 0;
    } catch (_) {
      return false;
    }
  }

    function ensureFrameOverlay(panel) {
      if (!panel || !panel.body) { return null; }
      var body = panel.body;
      var ov = null;
      for (var i = 0; i < body.children.length; i++) {
        var ch = body.children[i];
        if (ch && ch.classList && ch.classList.contains("vf-frame__overlay")) {
          ov = ch;
          break;
        }
      }
      if (ov) { return ov; }
      ov = document.createElement("div");
      ov.className = "vf-frame__overlay";
      body.appendChild(ov);
      return ov;
    }

    function applySceneCommands(data) {
      var deps = createRuntimeDependencies();
      var frame = deps.frame;
      var widgets = deps.widgets;
      var layer = getLayer();
      if (!Array.isArray(data)) {
        runtimeFail("applySceneCommands: expected array");
      }
      if (!layer || !frame) {
        runtimeFail("applySceneCommands: runtime shell not booted");
      }
      var upsertCount = data.filter(function(c) { return c && c.kind === "frame_upsert"; }).length;
      runtimeLog("info", "applySceneCommands: " + data.length + " commands, " + upsertCount + " frame_upserts");

      var upserts = data.filter(function(c) {
        return c && c.kind === "frame_upsert" && c.payload && c.payload.spec;
      });
      try {
        global.__vfSceneDeclaredFrameCount = upserts.length;
      } catch (_) {}
      var mounted = [];
      var panelById = Object.create(null);
      var nextPanelIds = Object.create(null);
      var pending = upserts.slice();
      var pass = 0;
      while (pending.length > 0) {
        pass += 1;
        var advanced = false;
        var nextPending = [];
        for (var i = 0; i < pending.length; i++) {
          var spec = pending[i].payload.spec;
          var flags = spec.flags || {};
          var id = spec.id != null ? String(spec.id) : "frame-" + i;
          var parentId = spec.parent_id != null ? String(spec.parent_id).trim() : "";
          if (parentId && !panelById[parentId]) {
            nextPending.push(pending[i]);
            continue;
          }
          var parentPanel = parentId ? panelById[parentId] : null;
          var mountLayer = parentPanel ? (ensureFrameOverlay(parentPanel) || layer) : layer;
          var rawTitle = spec.title != null ? String(spec.title).trim() : "";
          var rawName = spec.name != null ? String(spec.name).trim() : "";
          var title = rawTitle || rawName;
          var alpha = frame._coerceAlpha(spec.alpha, 1);
          var isMaster = spec.master === true;
          var tAlign = spec.title_align;
          var titleAlign = tAlign === "center" || tAlign === "right" || tAlign === "left" ? tAlign : "left";
          var rawDock = spec.dock_loc != null ? spec.dock_loc : spec.dock_location != null ? spec.dock_location : spec.minimized_dock;
          var dockLocation = frame.normalizeDockLocationKey(rawDock != null ? String(rawDock) : "bl");
          var dockable = flags.dockable !== false && flags.minimizable !== false;
          var panel = livePanelsById[id] || null;
          var createdPanel = false;
          var needsRemount = false;
          if (panel && panel.root && panel.root.parentElement !== mountLayer) {
            needsRemount = true;
          }
          if (needsRemount && panel && typeof panel.destroy === "function") {
            try { panel.destroy(); } catch (_) {}
            delete livePanelsById[id];
            panel = null;
          }
          if (!panel) {
            panel = frame.mount(mountLayer, {
              id: id,
              containerKind: spec.container_kind || "window",
              title: title,
              titleAlign: titleAlign,
              aspect: spec.aspect != null ? String(spec.aspect) : null,
              inLayerDrag: true,
              draggable: flags.draggable !== false,
              dockable: dockable,
              resizable: flags.resizable !== false,
              closable: flags.closable !== false,
              alpha: alpha,
              bodyTransparent: spec.body_transparent === true,
              master: isMaster,
              frameless: spec.frameless === true,
              toolbar: spec.toolbar,
              dockLocation: dockLocation,
              zIndexBase: 1000 + i * 2,
              onBeforeDestroy: function(frameId) {
                return function() {
                  if (widgets && widgets.onFrameClose) {
                    widgets.onFrameClose(frameId);
                  }
                };
              }(id),
              onFrameRemoved: function() {
                if (layer._vfMasterTeardown) { return; }
                if (runtimeAllowsHostExit() &&
                    countExitTrackedFrames(layer) === 0 &&
                    !runtimeHasStandaloneDisplayContent()) {
                  postExitToHost();
                }
              }
            });
            panel.root.style.opacity = "0";
            mounted.push({ panel: panel, spec: spec });
            createdPanel = true;
          }
          livePanelsById[id] = panel;
          if (!createdPanel && typeof panel.setTitle === "function") {
            panel.setTitle(title, titleAlign);
          }
          if (!createdPanel && typeof panel.setAlpha === "function") {
            panel.setAlpha(alpha);
          }
          nextPanelIds[id] = true;
          panel.root.dataset.vfExitCounted = spec.exit_counted === false ? "false" : "true";
          panelById[id] = panel;
          applySpecRectToPanel(panel, spec);
          var bodySignature = "";
          try {
            bodySignature = JSON.stringify({
              body: Array.isArray(spec.body) ? spec.body : [],
              body_layout: spec.body_layout || null,
              __vf_internal_html_components: Array.isArray(spec.__vf_internal_html_components)
                ? spec.__vf_internal_html_components : []
            });
          } catch (_) {
            bodySignature = "";
          }
          if (spec.body && Array.isArray(spec.body) && spec.body.length && widgets && widgets.mount &&
              panel.root.__vfBodySignature !== bodySignature) {
            widgets.mount(panel, id, spec.body, spec.body_layout);
            panel.root.__vfBodySignature = bodySignature;
            applySpecRectToPanel(panel, spec);
          } else if ((!spec.body || !Array.isArray(spec.body) || spec.body.length === 0) &&
                     panel.root.__vfBodySignature !== bodySignature) {
            var internalIdentities = Array.isArray(spec.__vf_internal_html_components)
              ? spec.__vf_internal_html_components : [];
            var preparedInternalTree = null;
            if (internalIdentities.length > 0) {
              if (!global.VfHtmlComponents || !global.VfHtmlComponents.__internal ||
                  typeof global.VfHtmlComponents.__internal.mountTree !== "function") {
                runtimeFail("applySceneCommands: internal HTML component runtime is unavailable");
              }
              preparedInternalTree = document.createElement("div");
              var preparedInternalElements = global.VfHtmlComponents.__internal.mountTree(
                preparedInternalTree,
                internalIdentities
              );
            }
            if (widgets && typeof widgets.clearFrame === "function") {
              widgets.clearFrame(id);
            }
            if (panel.body) {
              var body = panel.body;
              var ch = body.firstChild;
              while (ch) {
                var next = ch.nextSibling;
                if (!ch.classList || !ch.classList.contains("vf-frame__draw-canvas")) {
                  body.removeChild(ch);
                }
                ch = next;
              }
              if (preparedInternalTree) {
                while (preparedInternalTree.firstChild) {
                  body.appendChild(preparedInternalTree.firstChild);
                }
                if (typeof global.VfHtmlComponents.__internal.adoptTree === "function") {
                  global.VfHtmlComponents.__internal.adoptTree(panel.root, preparedInternalElements);
                }
              }
            }
            panel.root.__vfBodySignature = bodySignature;
            applySpecRectToPanel(panel, spec);
          }
          advanced = true;
        }
        if (!advanced) {
          var unresolved = nextPending.map(function(cmd) {
            var unresolvedSpec = cmd && cmd.payload && cmd.payload.spec ? cmd.payload.spec : {};
            var unresolvedId = unresolvedSpec.id != null ? String(unresolvedSpec.id) : "frame?";
            var unresolvedParent = unresolvedSpec.parent_id != null ? String(unresolvedSpec.parent_id) : "";
            return unresolvedId + (unresolvedParent ? ' -> parent "' + unresolvedParent + '"' : "");
          });
          runtimeFail("applySceneCommands: unresolved parent frame references: " + unresolved.join(", "));
        }
        pending = nextPending;
        if (pass > upserts.length + 2) {
          runtimeFail("applySceneCommands: exceeded frame resolution passes");
        }
      }
      syncNativeLayout();
      if (widgets && typeof widgets.refreshButtonGroups === "function") {
        widgets.refreshButtonGroups();
      }
      if (isLegacyFallbackActive()) {
        displayRefresh();
      }
      Object.keys(livePanelsById).forEach(function(existingId) {
        if (nextPanelIds[existingId]) { return; }
        var stalePanel = livePanelsById[existingId];
        delete livePanelsById[existingId];
        if (stalePanel && typeof stalePanel.destroy === "function") {
          try { stalePanel.destroy(); } catch (_) {}
        }
      });
      global.requestAnimationFrame(function() {
        global.requestAnimationFrame(function() {
          for (var m = 0; m < mounted.length; m++) {
            reapplySpecRect(mounted[m].panel, mounted[m].spec, "settled frame");
            mounted[m].panel.root.style.opacity = "";
          }
          runtimeLog("info", "applySceneCommands: settled visible frames=" + Object.keys(livePanelsById).length);
          if (widgets && typeof widgets.refreshButtonGroups === "function") {
            widgets.refreshButtonGroups();
          }
          syncNativeLayout();
          displayRefresh();
        });
      });
    }

    // A producer session belongs to one emitted VM execution. It calls this
    // actual scene adapter/frame renderer, and returns e982 capabilities only
    // after the original frame is mounted. No source id lookup or fake root.
    function createRetainedProducerSessionV1(bridge, sessionOptions) {
      sessionOptions = sessionOptions || {};
      var deps = createRuntimeDependencies(), displayRoot = getLayer();
      var internal = global.VfHtmlComponents && global.VfHtmlComponents.__internal;
      if (!bridge || bridge.abi !== "vkf-retained-owner-lookup-js-v1" ||
          !displayRoot || !(displayRoot instanceof global.Element) || !displayRoot.isConnected ||
          !deps.frame || typeof deps.frame.mount !== "function" || !internal)
        throw new Error("actual connected scene renderer and retained capability bridge are required");
      var implicitDisplay = null; // enrolled only when the compiled implicit producer executes
      var panels = [], byRoot = new WeakMap(), disposed = false;
      function live() {
        if (disposed || getLayer() !== displayRoot)
          throw new TypeError("retained producer session is disposed or its Display changed");
      }
      function vector(value, name) {
        if (!Array.isArray(value) || value.length !== 2 ||
            value.some(function(x) { return typeof x !== "number" || !Number.isFinite(x); }))
          throw new TypeError("actual retained " + name + " requires two finite evaluated coordinates");
        return value;
      }
      function produce(descriptor, parentCapability, args) {
        live();
        if (descriptor.concrete_type === "View" || descriptor.concrete_type === "Layer") {
          if (!parentCapability) throw new TypeError("retained View/Layer requires its actual parent Frame");
          var actualParent = bridge.resolve(parentCapability), owner = byRoot.get(actualParent);
          if (!["Frame<2>", "Frame<3>"].includes(bridge.kind(parentCapability)) || !owner || !owner.api || !owner.api.root.isConnected)
            throw new TypeError("retained View/Layer parent is foreign or disposed");
          var display = global.VfDisplay;
          if (!display || typeof display.createRetainedFrameSceneV1 !== "function")
            throw new Error("actual retained display renderer member factory is unavailable");
          if (!owner.renderer) owner.renderer = display.createRetainedFrameSceneV1(owner.api);
          var member;
          if (descriptor.concrete_type === "View" && descriptor.effect_kind === "push")
            member = owner.renderer.createView(args, descriptor.world_sequence);
          else if (descriptor.concrete_type === "Layer" &&
                   (descriptor.effect_kind === "add" || descriptor.effect_kind === "world_add"))
            member = owner.renderer.createLayer(args, descriptor.world_sequence);
          else throw new TypeError("retained producer concrete kind/effect mismatch");
          if (!owner.renderer.owns(member) || member.parent !== actualParent || member.viewport !== owner.api.body)
            throw new TypeError("actual renderer did not acknowledge its original member and viewport");
          byRoot.set(member, {owner: owner, kind: descriptor.concrete_type, parentCapability: parentCapability});
          return bridge.bindOwner(member, descriptor.concrete_type);
        }
        if (!["Frame<2>", "Frame<3>"].includes(descriptor.concrete_type) || descriptor.effect_kind !== "add_frame")
          throw new TypeError("unsupported retained renderer producer kind/effect");
        var container = descriptor.container_kind || "window";
        if (!["viewport", "window", "panel"].includes(container))
          throw new TypeError("unsupported retained Frame container kind");
        var parent = null, mountLayer = displayRoot;
        if (parentCapability === null) {
          if (container !== "viewport") throw new TypeError("only an implicit Viewport can omit its actual receiver");
          if (!implicitDisplay) implicitDisplay = bridge.bindOwner(displayRoot, "Display<2>");
          if (bridge.resolve(implicitDisplay) !== displayRoot)
            throw new TypeError("implicit Display identity changed");
        } else {
          var parentValue = bridge.resolve(parentCapability);
          parent = byRoot.get(parentValue);
          if (bridge.kind(parentCapability) === "Display<2>" && parentValue === displayRoot && container === "viewport") {
            parent = null;
          } else {
          if (!["Frame<2>", "Frame<3>"].includes(bridge.kind(parentCapability)) || !parent || !parent.api ||
              !parent.api.root.isConnected ||
              (parent.container !== "viewport" && !(container === "panel" && parent.container === "panel")))
            throw new TypeError("retained Frame receiver is foreign or cannot own this child");
          mountLayer = ensureFrameOverlay(parent.api);
          if (!mountLayer || !parent.api.root.contains(mountLayer))
            throw new Error("actual parent frame overlay is unavailable");
          }
        }
        var pos = vector(args.pos, "pos"), size = vector(args.size, "size");
        if (size.some(function(x) { return x <= 0; })) throw new RangeError("retained Frame size must be positive");
        if (args.title !== undefined && typeof args.title !== "string") throw new TypeError("retained Frame title must be str");
        if (args.toolbar !== undefined && args.toolbar !== null &&
            !["top", "right", "bottom", "left"].includes(args.toolbar))
          throw new TypeError("retained Frame toolbar is invalid");
        Object.keys(args).forEach(function(name) {
          if (!["pos", "size", "title", "toolbar"].includes(name))
            throw new TypeError("unsupported retained Frame creation argument " + name);
        });
        var api = deps.frame.mount(mountLayer, {
          containerKind: container, title: args.title || "", toolbar: args.toolbar,
          frameless: container === "viewport", draggable: container === "window",
          dockable: container === "window", resizable: container === "window",
          closable: container === "window", exitWhenLastFrameClosed: false
        });
        try {
          if (!api || !(api.root instanceof global.Element) || !(api.body instanceof global.Element) ||
              api.root.parentNode !== mountLayer || !api.root.contains(api.body) || !api.root.isConnected)
            throw new Error("actual frame renderer did not acknowledge its mounted original object");
          // The same existing scene layout function consumes the evaluated VKF
          // operands. No reference geometry, source AST replay or fixture rect.
          applySpecRectToPanel(api, {rect: {x: pos[0], y: pos[1], w: size[0], h: size[1]}});
          internal.adoptTree(api.root, []);
          var record = {api: api, parent: parent, container: container, concreteKind: descriptor.concrete_type,
            parentCapability: parentCapability === null ? implicitDisplay : parentCapability};
          panels.push(record); byRoot.set(api.root, record);
          syncNativeLayout();
          return bridge.bindOwner(api.root, descriptor.concrete_type);
        } catch (error) {
          if (api && typeof api.destroy === "function") api.destroy();
          throw error;
        }
      }
      function memberNodes(owner) {
        if (!owner.renderer) return [];
        var snapshot = owner.renderer.snapshot();
        function nodeFor(value, kind, children) {
          // Only an actual authored runtime id enters lookup. Anonymous
          // renderer members still own lifetime/render state and descendants.
          if (value.id === undefined) return children;
          return [{id: value.id, kind: kind, value: value, children: children}];
        }
        var viewNodes = [], assigned = new Set();
        snapshot.views.forEach(function(view) {
          var nodes = [];
          view.meshes.forEach(function(layer) {
            assigned.add(layer);
            internal.registerTypedTreeV1(layer, []);
            nodes = nodes.concat(nodeFor(layer, "Layer", []));
          });
          internal.registerTypedTreeV1(view, nodes);
          viewNodes = viewNodes.concat(nodeFor(view, "View", nodes));
        });
        snapshot.layers.forEach(function(layer) {
          if (!assigned.has(layer)) {
            internal.registerTypedTreeV1(layer, []);
            viewNodes = viewNodes.concat(nodeFor(layer, "Layer", []));
          }
        });
        internal.registerTypedTreeV1(owner.api.root, viewNodes);
        return viewNodes;
      }
      function beforeLookup(capability) {
        live();
        var value = bridge.resolve(capability), record = byRoot.get(value);
        if (value instanceof global.Element) {
          // Reconcile original loaded DOM and real nested Frames at this
          // source operation; retain982 duplicate/type/namespace rules.
          internal.adoptTree(value, []);
          var descendants = [];
          panels.forEach(function(panel) {
            if (panel.api.root === value || value.contains(panel.api.root))
              descendants = descendants.concat(memberNodes(panel));
          });
          // Proper renderer descendants of nested Frames share the receiving
          // original owner scope; siblings outside it never enter this tree.
          internal.registerTypedTreeV1(value, descendants);
        } else {
          if (!record || !record.owner || !record.owner.renderer ||
              !record.owner.renderer.owns(value))
            throw new TypeError("retained lookup receiver is foreign or disposed");
          memberNodes(record.owner);
        }
      }
      function observe() {
        live();
        return Object.freeze(panels.map(function(record) {
          beforeLookup(bridge.bindOwner(record.api.root, record.concreteKind));
          return Object.freeze({frame: record.api.root, parent: record.parentCapability,
            renderer: record.renderer ? record.renderer.snapshot() : null});
        }));
      }
      function parentOf(capability) {
        live();
        var record = byRoot.get(bridge.resolve(capability));
        if (!record) throw new TypeError("producer acknowledgement belongs to a foreign execution");
        return record.parentCapability;
      }
      function property(capability, name, mutation) {
        live();
        var value = bridge.resolve(capability), kind = bridge.kind(capability);
        var disabledKind = ["Button", "Input", "Select", "TextArea", "Option", "OptGroup", "FieldSet"].includes(kind);
        if (name === "disabled" && disabledKind && value instanceof global.Element && "disabled" in value) {
          if (mutation) {
            if (typeof mutation.value !== "boolean") throw new TypeError("disabled requires bit");
            var before = value.disabled; value.disabled = mutation.value;
            if (typeof sessionOptions.onRetainedEffect === "function")
              sessionOptions.onRetainedEffect({object: value, kind: kind, name: name, before: before, value: value.disabled});
          }
          return value.disabled;
        }
        if (name === "title" && kind === "Frame<2>") {
          var panel = byRoot.get(value);
          if (!panel) throw new TypeError("retained Frame property belongs to a foreign execution");
          if (mutation) {
            if (typeof mutation.value !== "string") throw new TypeError("Frame title requires str");
            panel.api.setTitle(mutation.value);
          }
          return panel.api.titleEl.textContent;
        }
        throw new TypeError("unimplemented concrete retained property " + kind + "." + name);
      }
      function dispose() {
        if (disposed) return;
        disposed = true;
        var failures = [];
        for (var i = panels.length - 1; i >= 0; i--) {
          try { if (panels[i].renderer) panels[i].renderer.dispose(); } catch (error) { failures.push(error); }
          try { panels[i].api.destroy(); } catch (error) { failures.push(error); }
        }
        panels.length = 0; byRoot = new WeakMap(); implicitDisplay = null;
        try { syncNativeLayout(); } catch (error) { failures.push(error); }
        if (failures.length) throw new AggregateError(failures, "actual retained renderer disposal failed");
      }
      return Object.freeze({abi: "vkf-retained-renderer-producer-v1", produce: produce, parentOf: parentOf, beforeLookup: beforeLookup, property: property, observe: observe, dispose: dispose});
    }

    return {
      createRetainedProducerSessionV1: createRetainedProducerSessionV1,
      syncNativeLayout: syncNativeLayout,
      applySceneCommands: applySceneCommands,
      applyInternalHtmlPatchPacket: applyInternalHtmlPatchPacket
    };
  }

  global.VfRuntimeScene = {
    createAdapter: createAdapter
  };
})(typeof window !== "undefined" ? window : this);
