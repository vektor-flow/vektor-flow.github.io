Vektor Flow0.7.5 native Linux x86_64 CLI focused graph/compiler candidate.
Binding df9feb23d8c23cb9f7ac94953dcf5dd4cb1756dfd074017e7e8d51ba00a6c465.
Actual current35 filesystem sources/registry28, distinct from browser34/27.
No newABI2 runtime/UI helper/embedded engine/fullSDK qualification; nativeScene/deployed/fullframe10ms OPEN. Extracted binding/compile/full record+graph output PASS. Existing system runtime prerequisites required.
