Current x86_64 Linux strict native CLI and the32 byte-verified paired standard-library sources.

From an extracted directory:
  ./bin/vkf --source-binding
  ./bin/vkf /absolute/program.vkf
  ./bin/vkf -b /absolute/program.vkf -o /absolute/program

Source 89f64c311913343cd17ffe4f3329296ed291d229; binding f3768ef2e11c33d180431e6732ddcd4272552594d4a653a56ddc771ba3faa97a; binary SHA256 7f039e6ab3ea12c5756a376f64b93c8490d707f94b6f1c98388a3714e4487fcc. Tested from projects outside the compiler source checkout: all20 native interpolation/Morphing compatibility fixtures and source-address/cache edit/missing/map/target checks. Morphing is project-library input. This is the tested console CLI/source installation, not an unsupported full standalone SDK claim. The root .stdlib umbrella file is absent in selected source and is not fabricated. FullSDK/rootumbrella/broadUI/standards/GPU/benchmark scopes are not newly imposed release gates.
