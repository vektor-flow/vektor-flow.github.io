Stanford University Computer Graphics Laboratory. Research and free redistribution with attribution; commercial use requires permission. https://graphics.stanford.edu/data/3Dscanrep/
Native VKF remeshed bunny, midpoint and armadillo; these are reduced-detail reconstructions.
