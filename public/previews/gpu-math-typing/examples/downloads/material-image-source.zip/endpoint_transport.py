"""CPU reference: balanced pixel assignment between two masked image states.

Inputs are independent RGBA images with binary masks, on the same canvas.
The assignment is inferred globally; no polar cut, destination object count,
hand-authored vertex correspondence, or opacity blend of whole images is used.
This small-image reference is quadratic in memory, not a general photo segmenter.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
from scipy.spatial import Delaunay
from image_transport import linear, srgb
from pixel_transport import clock


class EndpointTransport:
 def __init__(self, source, target, appearance_weight=0., max_samples=12000):
  self.a=np.asarray(source);self.b=np.asarray(target)
  if self.a.shape!=self.b.shape or self.a.ndim!=3 or self.a.shape[2]!=4 or self.a.dtype!=np.uint8 or self.b.dtype!=np.uint8:
   raise ValueError('Expected equally sized uint8 RGBA states')
  if not np.isfinite(appearance_weight) or appearance_weight<0:raise ValueError('Invalid appearance weight')
  if any(np.any((im[...,3]!=0)&(im[...,3]!=255)) for im in (self.a,self.b)):
   raise ValueError('Reference solver requires binary alpha masks')
  self.shape=self.a.shape[:2]
  points=[np.argwhere(im[...,3]>0) for im in (self.a,self.b)]
  count=max(map(len,points))
  if not min(map(len,points)) or count>max_samples:raise ValueError('Empty mask or sample budget exceeded')
  # Stratified duplication supports unequal endpoint areas while covering every
  # occupied pixel. Density changes are reported, not called area preservation.
  self.source,self.target=[p[np.floor((np.arange(count)+.5)*len(p)/count).astype(int)] for p in points]
  self.ca=linear(self.a[tuple(self.source.T)][:,:3]/255.)
  cb=linear(self.b[tuple(self.target.T)][:,:3]/255.)
  scale=max(self.shape)
  cost=cdist(self.source/scale,self.target/scale,'sqeuclidean')
  if appearance_weight:cost+=appearance_weight*cdist(self.ca,cb,'sqeuclidean')
  _,order=linear_sum_assignment(cost)
  self.target=self.target[order];self.cb=cb[order]
  self.mass=len(points[0])/count
  self.endpoint_areas=list(map(len,points))

 def frame(self,t,smooth=True):
  if not np.isfinite(t) or not 0<=t<=1:raise ValueError('Progress must be in [0,1]')
  u=clock(t) if smooth else t
  coords=(1-u)*self.source+u*self.target
  colors=(1-u)*self.ca+u*self.cb
  h,w=self.shape;base=np.floor(coords).astype(int);f=coords-base
  density=np.zeros(h*w);rgb=np.zeros((h*w,3))
  for dy,dx,weight in [(0,0,(1-f[:,0])*(1-f[:,1])),(0,1,(1-f[:,0])*f[:,1]),(1,0,f[:,0]*(1-f[:,1])),(1,1,f[:,0]*f[:,1])]:
   yy=base[:,0]+dy;xx=base[:,1]+dx;valid=(yy>=0)&(yy<h)&(xx>=0)&(xx<w)
   ix=yy[valid]*w+xx[valid];ww=weight[valid]*self.mass
   density+=np.bincount(ix,weights=ww,minlength=h*w)
   for c in range(3):rgb[:,c]+=np.bincount(ix,weights=ww*colors[valid,c],minlength=h*w)
  rgb/=np.maximum(density[:,None],1e-15)
  # Reconstruct a continuous material surface rather than displaying isolated
  # pixel splats. Reject triangles that join distant endpoint neighborhoods:
  # this allows a split without drawing a bridge across the target gap.
  if t not in (0,1) and not np.all(self.target-self.source==self.target[0]-self.source[0]) and len(coords)>=3 and np.linalg.matrix_rank(coords-coords[0])==2:
   mesh=Delaunay(coords)
   triangles=mesh.simplices
   valid=np.ones(len(triangles),bool)
   for points in (self.source,self.target):
    for i,j in [(0,1),(1,2),(2,0)]:
     valid &= np.linalg.norm(points[triangles[:,i]]-points[triangles[:,j]],axis=1)<=4
   sample=np.indices((h*2,w*2),dtype=float).reshape(2,-1).T/2-.25
   simplex=mesh.find_simplex(sample);inside=(simplex>=0)&valid[np.maximum(simplex,0)]
   ids=simplex[inside];trans=mesh.transform[ids]
   bary=np.einsum('nij,nj->ni',trans[:,:2],sample[inside]-trans[:,2])
   weights=np.column_stack([bary,1-bary.sum(axis=1)])
   values=np.einsum('ni,nic->nc',weights,colors[triangles[ids]])
   premul=np.zeros((h*2*w*2,3));premul[inside]=values
   alpha=inside.reshape(h,2,w,2).mean(axis=(1,3))
   rgb=premul.reshape(h,2,w,2,3).mean(axis=(1,3))/np.maximum(alpha[...,None],1e-15)
   result=np.concatenate([srgb(np.clip(rgb,0,1)),alpha[...,None]],axis=2)
  else:
   alpha=np.clip(density,0,1)
   result=np.concatenate([srgb(np.clip(rgb,0,1)),alpha[:,None]],axis=1).reshape(h,w,4)
  result=np.rint(np.clip(result,0,1)*255).astype(np.uint8)
  # Exact supplied states, including invisible RGB. The particle positions and
  # visible RGB already arrive at these endpoints; this restores binary alpha.
  if t==0:result=self.a.copy()
  if t==1:result=self.b.copy()
  return result,dict(progress=float(t),mass=float(density.sum()),visible_area=float((result[...,3]/255.).sum()),occupied_pixels=int(np.count_nonzero(result[...,3])))
