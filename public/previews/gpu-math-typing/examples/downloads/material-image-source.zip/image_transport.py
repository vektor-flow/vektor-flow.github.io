"""CPU reference: endpoint-inferred translation of textured RGBA parts.

Rejected as an image-morph demonstration on 2026-10-16: exchanging intact tiles
does not meet the requested internal pixel deformation/structure preservation.

Separated alpha components must match exactly in appearance at both endpoints.
Overlap is permitted during transport; later source components paint in front.
This deliberately rejects deformation, endpoint occlusion and photo segmentation.
"""
from dataclasses import dataclass
import numpy as np
from scipy import ndimage as ndi
from scipy.optimize import linear_sum_assignment
from pixel_transport import clock


def linear(rgb):
    return np.where(rgb <= .04045, rgb / 12.92, ((rgb + .055) / 1.055) ** 2.4)


def srgb(rgb):
    return np.where(rgb <= .0031308, 12.92 * rgb,
                    1.055 * np.maximum(rgb, 0) ** (1 / 2.4) - .055)


def rgba(image):
    a = np.asarray(image)
    if a.ndim != 3 or a.shape[2] != 4 or a.dtype != np.uint8:
        raise ValueError('Expected an H×W×4 uint8 RGBA image')
    if not np.any(a[..., 3]):
        raise ValueError('Expected nonempty foreground')
    a = a.copy()
    a[a[..., 3] == 0] = 0  # Invisible RGB is not material.
    return a


@dataclass
class Part:
    patch: np.ndarray
    origin: np.ndarray  # y, x


def parts(image):
    labels, count = ndi.label(image[..., 3] > 0, np.ones((3, 3)))
    if count > 32:
        raise ValueError('Reference bounded to 32 alpha components')
    result = []
    for i, box in enumerate(ndi.find_objects(labels), 1):
        patch = image[box].copy()
        patch[labels[box] != i] = 0
        result.append(Part(patch, np.array([s.start for s in box])))
    return result


class ImageTransport:
    def __init__(self, source, target):
        self.source, self.target = rgba(source), rgba(target)
        if self.source.shape != self.target.shape:
            raise ValueError('Images must have equal canvas dimensions')
        self.a, self.b = parts(self.source), parts(self.target)
        if len(self.a) != len(self.b):
            raise ValueError('Split, merge or endpoint occlusion requires a richer model')
        compatible = np.array([[p.patch.shape == q.patch.shape and
                                np.array_equal(p.patch, q.patch)
                                for q in self.b] for p in self.a])
        distances = np.array([[np.linalg.norm(p.origin - q.origin)
                               for q in self.b] for p in self.a])
        # Appearance is a hard constraint; travel only disambiguates duplicates.
        costs = np.where(compatible, distances / (1 + distances.max()), 1e6)
        rows, cols = linear_sum_assignment(costs)
        if not compatible[rows, cols].all():
            raise ValueError('Unexplained appearance/deformation: no exact translation correspondence')
        self.matches = [int(j) for j in cols]
        self.ambiguous_parts = int(np.count_nonzero(compatible.sum(axis=1) > 1))
        self.fields = []
        for part in self.a:
            field = np.zeros(self.source.shape, float)
            y, x = part.origin
            h, w = part.patch.shape[:2]
            alpha = part.patch[..., 3:4] / 255.
            field[y:y+h, x:x+w] = np.concatenate(
                (linear(part.patch[..., :3] / 255.) * alpha, alpha), axis=2)
            self.fields.append(field)

    def layers(self, t):
        if not np.isfinite(t) or not 0 <= t <= 1:
            raise ValueError('Time must be finite and between zero and one')
        u = clock(t)
        result = []
        for i, j in enumerate(self.matches):
            delta = u * (self.b[j].origin - self.a[i].origin)
            # Inverse bilinear sampling of premultiplied linear colour. The
            # convex translation path stays inside the common endpoint canvas.
            result.append(ndi.shift(self.fields[i], (*delta, 0), order=1,
                                    mode='grid-constant', cval=0, prefilter=False))
        return result

    def frame(self, t):
        layers = self.layers(t)
        composite = np.zeros(self.source.shape, float)
        for layer in layers:
            composite = layer + composite * (1 - layer[..., 3:4])
        alpha = composite[..., 3:4]
        colour = np.divide(composite[..., :3], alpha,
                           out=np.zeros_like(composite[..., :3]), where=alpha > 0)
        return np.rint(np.clip(np.concatenate((srgb(colour), alpha), axis=2), 0, 1) * 255).astype(np.uint8)
