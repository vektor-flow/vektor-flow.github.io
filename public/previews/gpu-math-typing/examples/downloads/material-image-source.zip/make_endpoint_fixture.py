"""Independent smooth RGBA endpoint fixtures; no transport map is supplied."""
from pathlib import Path
import argparse
import numpy as np
from PIL import Image


def states(size=128):
 y,x=np.indices((size,size),dtype=float);x=(x+.5)/size;y=(y+.5)/size
 def draw(centers,radius):
  im=np.zeros((size,size,4),np.uint8)
  for cx,cy in centers:
   xx=(x-cx)/radius;yy=(y-cy)/radius;mask=xx*xx+yy*yy<=1
   # Smooth Cartesian bands, continuous everywhere inside each target shape.
   band=(1+np.cos(yy*3*np.pi))/2
   rgb=np.stack([45+115*band,155+65*band,185+55*band],axis=-1)
   im[mask,:3]=np.rint(rgb[mask]).astype(np.uint8);im[mask,3]=255
  return im
 return draw([(.5,.5)],.297),draw([(.245,.5),(.755,.5)],.297/np.sqrt(2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 for name,im in zip(['source','target'],states()):Image.fromarray(im).save(a.output/f'{name}.png')
