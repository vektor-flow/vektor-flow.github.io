"""Many-to-many image material transport, without endpoint image opacity layers.

Each branch carries fixed mass and moves from a source sample to a destination.
Its RGB appearance changes along that path. Source mass can split and destination
material can combine; target density need not equal the initial density.
"""
import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import cKDTree
from photo_transport import validate_image
from image_transport import linear,srgb
from pixel_transport import clock


def material_coupling(a,b,predicted,descriptors=None,neighbors=12):
    """Sparse many-to-many coupling with exact source mass and target coverage.

    Target density may differ: shrinking an eye concentrates its material instead
    of forcing surplus eye pixels to remain spread across the target face.
    """
    h,w=a.shape[:2];n=h*w;scale=np.array([h,w])
    grid=np.indices((h,w),dtype=float).reshape(2,-1).T
    if descriptors is None:
        fa,fb=[linear(im.reshape(-1,3)/255.) for im in [a,b]]
    else:fa,fb=descriptors
    source_feature=np.column_stack([fa,predicted/scale*3])
    target_feature=np.column_stack([fb,grid/scale*3])
    _,forward=cKDTree(target_feature).query(source_feature,k=1,workers=1)
    _,backward=cKDTree(source_feature).query(target_feature,k=1,workers=1)
    codes=np.unique(np.r_[np.arange(n)*n+forward,backward*n+np.arange(n)])
    source,target=codes//n,codes%n
    mass=1/np.bincount(source,minlength=n)[source]
    return source,target,mass


class MaterialTransport:
    def __init__(self,a,b,coupling):
        self.a,self.b=validate_image(a),validate_image(b)
        if self.a.shape!=self.b.shape:raise ValueError('Canvas sizes differ')
        self.source_index,self.target_index,self.mass=[np.asarray(x) for x in coupling]
        n=self.a.shape[0]*self.a.shape[1]
        if self.source_index.ndim!=1 or not (self.source_index.shape==self.target_index.shape==self.mass.shape):raise ValueError('Invalid coupling shape')
        for indices in [self.source_index,self.target_index]:
            if not np.issubdtype(indices.dtype,np.integer) or indices.min()<0 or indices.max()>=n or np.unique(indices).size!=n:raise ValueError('Coupling must cover each endpoint')
        if not np.isfinite(self.mass).all() or (self.mass<=0).any():raise ValueError('Invalid material masses')
        grid=np.indices(self.a.shape[:2],dtype=float).reshape(2,-1).T
        self.source=grid[self.source_index];self.target=grid[self.target_index]
        self.colours=[linear(a.reshape(-1,3)[self.source_index]/255.),linear(b.reshape(-1,3)[self.target_index]/255.)]
    def frame(self,t,timing='smooth'):
        if not np.isfinite(t) or not 0<=t<=1:raise ValueError('Invalid progress')
        if timing not in ['smooth','linear']:raise ValueError('Unknown timing')
        u=clock(t) if timing=='smooth' else t
        coords=(1-u)*self.source+u*self.target
        appearance=(1-u)*self.colours[0]+u*self.colours[1]
        h,w=self.a.shape[:2];n=h*w
        colour=np.zeros((n,3));mass=np.zeros(n)
        base=np.floor(coords).astype(int);fraction=coords-base
        for dy,dx,weight in [(0,0,(1-fraction[:,0])*(1-fraction[:,1])),(0,1,(1-fraction[:,0])*fraction[:,1]),(1,0,fraction[:,0]*(1-fraction[:,1])),(1,1,fraction[:,0]*fraction[:,1])]:
            y=base[:,0]+dy;x=base[:,1]+dx
            valid=(y>=0)&(y<h)&(x>=0)&(x<w);index=y[valid]*w+x[valid];weight=weight[valid]*self.mass[valid]
            mass+=np.bincount(index,weights=weight,minlength=n)
            for c in range(3):colour[:,c]+=np.bincount(index,weights=weight*appearance[valid,c],minlength=n)
        missing=(mass<1e-10).reshape(h,w)
        colour=(colour/np.maximum(mass,1e-10)[:,None]).reshape(h,w,3)
        if missing.any():
            near=ndi.distance_transform_edt(missing,return_distances=False,return_indices=True)
            colour[missing]=colour[tuple(near[:,missing])]
        im=np.rint(np.clip(srgb(colour),0,1)*255).astype(np.uint8)
        return im,dict(material_mass=float(mass.sum()),material_branches=len(self.mass),
                       splitting_samples=int(np.sum(np.bincount(self.source_index)>1)),
                       combining_destinations=int(np.sum(np.bincount(self.target_index)>1)),missing_fraction=float(missing.mean()))


def geometric_coupling(predicted,inverse,shape):
    """Subpixel material branches from coherent forward/inverse region maps."""
    h,w=shape;n=h*w
    sources=[];targets=[];weights=[]
    for coords,backward in [(predicted,False),(inverse,True)]:
        coords=np.clip(coords,[0,0],[h-1,w-1]);base=np.floor(coords).astype(int);frac=coords-base
        for dy,dx,weight in [(0,0,(1-frac[:,0])*(1-frac[:,1])),(0,1,(1-frac[:,0])*frac[:,1]),(1,0,frac[:,0]*(1-frac[:,1])),(1,1,frac[:,0]*frac[:,1])]:
            y=base[:,0]+dy;x=base[:,1]+dx;valid=(y<h)&(x<w)&(weight>1e-12)
            other=y[valid]*w+x[valid];index=np.arange(n)[valid]
            sources.append(other if backward else index);targets.append(index if backward else other);weights.append(weight[valid])
    source=np.concatenate(sources);target=np.concatenate(targets);mass=np.concatenate(weights)
    codes,indices=np.unique(source*n+target,return_inverse=True)
    mass=np.bincount(indices,weights=mass);source=codes//n;target=codes%n
    mass/=np.bincount(source,weights=mass,minlength=n)[source]
    return source,target,mass
