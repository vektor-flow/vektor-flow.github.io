"""Object assignment and semantic-part guided coherent image deformation.

Perception is supplied separately as instance masks and normalized descriptors.
This module accepts arbitrary object counts and never reads hand-labelled points.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.interpolate import RBFInterpolator
from scipy import ndimage as ndi
from photo_mesh import PhotoMesh


def patch_grid(shape, grid_shape):
    y,x=np.indices(grid_shape,dtype=float)
    return np.column_stack(((y.ravel()+.5)*shape[0]/grid_shape[0]-.5,
                            (x.ravel()+.5)*shape[1]/grid_shape[1]-.5))


def object_descriptors(state, shape):
    features=state['features'].reshape(-1,state['features'].shape[-1])
    coords=patch_grid(shape,state['features'].shape[:2])
    masks=np.array([ndi.map_coordinates(mask,coords.T,order=1)>.5 for mask in state['masks']])
    descriptors=np.array([features[m].mean(axis=0) if m.any() else np.zeros(features.shape[1]) for m in masks])
    if len(descriptors): descriptors/=np.maximum(np.linalg.norm(descriptors,axis=1,keepdims=True),1e-12)
    return coords,masks,features,descriptors


def match_objects(source,target,shape):
    sa=object_descriptors(source,shape);sb=object_descriptors(target,shape)
    if not len(sa[3]) or not len(sb[3]):return [],sa,sb
    # Labels are weak evidence: different classes can intentionally transform.
    cost=1-sa[3]@sb[3].T+.05*(source['labels'][:,None]!=target['labels'][None,:])
    ii,jj=linear_sum_assignment(cost)
    matches=[(int(i),int(j),float(1-cost[i,j])) for i,j in zip(ii,jj) if cost[i,j]<.9]
    return matches,sa,sb


def semantic_controls(source,target,shape):
    matches,sa,sb=match_objects(source,target,shape)
    points=[]
    for ia,ib,object_confidence in matches:
        ai=np.flatnonzero(sa[1][ia]);bi=np.flatnonzero(sb[1][ib])
        pa,pb=sa[0][ai],sb[0][bi]
        boxa=source['boxes'][ia][[1,0,3,2]];boxb=target['boxes'][ib][[1,0,3,2]]
        ra=(pa-boxa[:2])/np.maximum(boxa[2:]-boxa[:2],1)
        rb=(pb-boxb[:2])/np.maximum(boxb[2:]-boxb[:2],1)
        cosine=sa[2][ai]@sb[2][bi].T
        cost=cosine-.3*np.sum((ra[:,None]-rb[None,:])**2,axis=-1)
        best=cost.argmax(axis=1);reverse=cost.argmax(axis=0)
        candidates=[]
        for i,j in enumerate(best):
            if reverse[j]!=i or cosine[i,j]<.35:continue
            candidates.append((float(cost[i,j]),pa[i],pb[j],float(cosine[i,j])))
        # Spatial coverage matters more than a large cluster of fur matches.
        chosen=[]
        for confidence,p,q,cos in sorted(candidates,key=lambda r:-r[0]):
            if any(np.linalg.norm(p-r[1])<20 or np.linalg.norm(q-r[2])<20 for r in chosen):continue
            chosen.append((confidence,p,q,cos))
            if len(chosen)>=80:break
        points += [dict(source=p.tolist(),target=q.tolist(),confidence=cos,source_object=ia,target_object=ib) for _,p,q,cos in chosen]
    return matches,points


class ObjectMorph(PhotoMesh):
    def __init__(self,a,b,source_state,target_state,spacing=12):
        super().__init__(a,b,flow=np.zeros((2,*a.shape[:2])),spacing=spacing)
        self.objects,self.controls=semantic_controls(source_state,target_state,a.shape[:2])
        if len(self.controls)<4:raise ValueError('Not enough reliable semantic correspondences')
        h,w=a.shape[:2];scale=np.array([h-1,w-1])
        source=np.array([p['source'] for p in self.controls])/scale
        target=np.array([p['target'] for p in self.controls])/scale
        edge=np.any((self.source==0)|(self.source==scale),axis=1)
        boundary=self.source[edge]/scale
        points=np.vstack([source,boundary]);delta=np.vstack([target-source,np.zeros_like(boundary)])
        self.regularization=None
        for smoothing in [.001,.003,.01,.03,.1,.3,1]:
            displacement=RBFInterpolator(points,delta,smoothing=np.r_[np.full(len(source),smoothing),np.full(len(boundary),.000001)],kernel='thin_plate_spline')(self.source/scale)*scale
            displacement[edge]=0
            self.target=np.clip(self.source+displacement,[0,0],scale)
            if all(self.structure(t,timing='linear')['compression_p05']>.12 and self.structure(t,timing='linear')['fold_fraction']==0 for t in np.linspace(0,1,17)):
                self.regularization=smoothing;break
        if self.regularization is None:raise ValueError('Semantic correspondences cannot form a coherent mesh')
