"""Shared connected texture mesh for photo morph experiments.

One source-to-target field defines both texture warps. Overlapping triangles
accumulate; they are not routed around each other. This fixes independent-warp
gaps, not the harder problem of semantic image correspondence.
"""
import numpy as np
from scipy import ndimage as ndi
from photo_transport import validate_image, estimate_flow
from image_transport import linear, srgb
from pixel_transport import clock


class PhotoMesh:
    def __init__(self, a, b, flow=None, spacing=24):
        self.a, self.b = validate_image(a), validate_image(b)
        if self.a.shape != self.b.shape: raise ValueError('Canvas sizes differ')
        h, w = a.shape[:2]
        flow = estimate_flow(a, b) if flow is None else np.asarray(flow)
        if flow.shape != (2, h, w) or not np.isfinite(flow).all():
            raise ValueError('Invalid flow')
        ny, nx = max(2, int(np.ceil(h/spacing))+1), max(2, int(np.ceil(w/spacing))+1)
        yy, xx = np.meshgrid(np.linspace(0, h-1, ny), np.linspace(0, w-1, nx), indexing='ij')
        self.source = np.column_stack((yy.ravel(), xx.ravel()))
        delta = np.column_stack([ndi.map_coordinates(f, [yy.ravel(), xx.ravel()], order=1) for f in flow])
        # Keep the one image canvas fixed; transition smoothly into that boundary.
        edge = np.minimum.reduce([yy/(h-1), 1-yy/(h-1), xx/(w-1), 1-xx/(w-1)])
        delta *= np.minimum(1, edge.ravel()/.18)[:, None]
        triangles = []
        for y in range(ny-1):
            for x in range(nx-1):
                i = y*nx+x
                triangles.extend([[i, i+nx, i+1], [i+nx, i+nx+1, i+1]])
        self.triangles = np.array(triangles)
        self.target = self.source + delta
        self.colours = [linear(im/255.) for im in [self.a, self.b]]

    @staticmethod
    def progress(t, timing):
        if timing not in ['smooth', 'linear']: raise ValueError('Unknown timing mode')
        return clock(t) if timing == 'smooth' else t

    def structure(self, t, timing='smooth'):
        vertices = self.source + self.progress(t, timing)*(self.target-self.source)
        def edges(v):
            p = v[self.triangles]
            return np.stack([p[:, 1]-p[:, 0], p[:, 2]-p[:, 0]], axis=-1)
        transform = edges(vertices) @ np.linalg.inv(edges(self.source))
        sv = np.linalg.svd(transform, compute_uv=False)
        return dict(fold_fraction=float(np.mean(np.linalg.det(transform) <= 0)),
                    stretch_p95=float(np.quantile(sv[:, 0], .95)),
                    compression_p05=float(np.quantile(sv[:, 1], .05)))

    def frame(self, t, rotation_degrees=0., canvas_shape=None, timing='smooth'):
        if not np.isfinite(t) or not 0 <= t <= 1: raise ValueError('Time must be in [0,1]')
        if not np.isfinite(rotation_degrees): raise ValueError('Rotation must be finite')
        u = self.progress(t, timing)
        native_shape = np.array(self.a.shape[:2])
        h, w = self.a.shape[:2] if canvas_shape is None else canvas_shape
        if min(h, w) < 1: raise ValueError('Invalid canvas size')
        vertices = (1-u)*self.source + u*self.target
        theta = np.deg2rad(rotation_degrees)
        rotation = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
        # Rotate geometry, not the already-rendered bitmap: one texture sample.
        vertices = (vertices-(native_shape-1)/2) @ rotation.T + (np.array([h,w])-1)/2
        output = np.zeros((h, w, 3), float)
        count = np.zeros((h, w), float)
        for ids in self.triangles:
            tri = vertices[ids]
            lo = np.maximum(0, np.floor(tri.min(axis=0)).astype(int))
            hi = np.minimum([h-1, w-1], np.ceil(tri.max(axis=0)).astype(int))
            if np.any(hi < lo): continue
            yy, xx = np.mgrid[lo[0]:hi[0]+1, lo[1]:hi[1]+1]
            matrix = (tri[1:]-tri[0]).T
            if abs(np.linalg.det(matrix)) < 1e-9: continue
            bary = np.linalg.solve(matrix, np.array([yy.ravel()-tri[0, 0], xx.ravel()-tri[0, 1]]))
            weights = np.vstack([1-bary.sum(axis=0), bary])
            inside = np.all(weights >= -1e-7, axis=0)
            weights = weights[:, inside]
            ry, rx = yy.ravel()[inside], xx.ravel()[inside]
            rgb = np.zeros((len(ry), 3))
            for image, endpoint, amount in zip(self.colours, [self.source, self.target], [1-u, u]):
                coords = endpoint[ids].T @ weights
                rgb += amount*np.column_stack([ndi.map_coordinates(image[..., c], coords, order=1, mode='nearest') for c in range(3)])
            output[ry, rx] += rgb
            count[ry, rx] += 1
        grid = np.indices((h, w)).reshape(2, -1).T
        local = (grid-(np.array([h,w])-1)/2) @ rotation + (native_shape-1)/2
        support = np.all((local >= -1e-7) & (local <= native_shape-1+1e-7), axis=1).reshape(h,w)
        missing = (count == 0) & support
        output /= np.maximum(count[..., None], 1)
        if missing.any():
            near = ndi.distance_transform_edt(count == 0, return_distances=False, return_indices=True)
            output[missing] = output[tuple(near[:, missing])]
        output[~support] = linear(np.array([17, 27, 38])/255.)
        # With no folds, barycentric interpolation reproduces both endpoints.
        image = np.rint(np.clip(srgb(output), 0, 1)*255).astype(np.uint8)
        return image, dict(missing_fraction=float(missing.sum()/max(1, support.sum())),
                           rotation_degrees=float(rotation_degrees), **self.structure(t, timing))
