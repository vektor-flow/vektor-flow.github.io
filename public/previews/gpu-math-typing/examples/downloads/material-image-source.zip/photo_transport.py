"""Experimental endpoint-only dense photo morph, CPU reference.

TV-L1 luminance matching plus spatial flow regularization; no semantic landmarks.
Forward splatting permits internal overlap. Appearance interpolates in linear
light along the two estimated motion fields. This is not texture conservation
or a guarantee of correct cross-species correspondence.
"""
import numpy as np
from scipy import ndimage as ndi
from skimage.registration import optical_flow_tvl1
from skimage.transform import resize
from image_transport import linear, srgb
from pixel_transport import clock


def validate_image(image):
    image = np.asarray(image)
    if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
        raise ValueError('Expected uint8 RGB image')
    if min(image.shape[:2]) < 8:
        raise ValueError('Image must be at least 8 by 8')
    return image.copy()


def estimate_flow(a, b, smooth=4):
    shape = a.shape[:2]
    scale = min(1., 256 / max(shape))
    small = tuple(max(8, round(v * scale)) for v in shape)
    def grey(im):
        rgb = resize(im, (*small, 3), anti_aliasing=True)
        return ndi.gaussian_filter(rgb @ np.array([.2126, .7152, .0722]), 1).astype(np.float32)
    flow = optical_flow_tvl1(grey(a), grey(b), attachment=8, tightness=.2,
                             num_warp=10, num_iter=20, prefilter=True)
    flow = np.array([ndi.gaussian_filter(f, smooth) for f in flow])
    flow = np.array([resize(f, shape, preserve_range=True) * shape[i] / small[i]
                     for i, f in enumerate(flow)])
    grid = np.indices(shape, dtype=float)
    # Endpoint coordinates in the canvas imply every interpolated path is in it.
    for i in range(2):
        flow[i] = np.clip(grid[i] + flow[i], 0, shape[i] - 1) - grid[i]
    return flow


def splat(values, coords):
    """Bilinear deposition; collisions accumulate rather than route away."""
    h, w = values.shape[:2]
    y, x = coords
    y0, x0 = np.floor(y).astype(int), np.floor(x).astype(int)
    fy, fx = y - y0, x - x0
    mass = np.zeros(h * w)
    colour = np.zeros((h * w, 3))
    for dy, dx, weight in [(0, 0, (1-fy)*(1-fx)), (0, 1, (1-fy)*fx),
                           (1, 0, fy*(1-fx)), (1, 1, fy*fx)]:
        yy, xx = y0 + dy, x0 + dx
        valid = (yy >= 0) & (yy < h) & (xx >= 0) & (xx < w)
        idx = (yy[valid] * w + xx[valid]).ravel()
        ww = weight[valid].ravel()
        mass += np.bincount(idx, weights=ww, minlength=h*w)
        for c in range(3):
            colour[:, c] += np.bincount(idx, weights=ww*values[..., c][valid], minlength=h*w)
    return colour.reshape(h, w, 3), mass.reshape(h, w)


def distortion(flow, progress):
    dy_y, dy_x = np.gradient(progress * flow[0])
    dx_y, dx_x = np.gradient(progress * flow[1])
    jac = np.stack([1 + dy_y, dy_x, dx_y, 1 + dx_x], axis=-1).reshape(*flow.shape[1:], 2, 2)
    singular = np.linalg.svd(jac, compute_uv=False)
    det = (1+dy_y)*(1+dx_x) - dy_x*dx_y
    return dict(fold_fraction=float(np.mean(det <= 0)),
                stretch_p95=float(np.quantile(singular[..., 0], .95)),
                compression_p05=float(np.quantile(singular[..., 1], .05)))


class PhotoTransport:
    def __init__(self, a, b, flows=None, smooth=4):
        self.a, self.b = validate_image(a), validate_image(b)
        if self.a.shape != self.b.shape:
            raise ValueError('Images must share a canvas size')
        self.grid = np.indices(self.a.shape[:2], dtype=float)
        self.colours = [linear(im / 255.) for im in [self.a, self.b]]
        self.flows = ([estimate_flow(self.a, self.b, smooth), estimate_flow(self.b, self.a, smooth)]
                      if flows is None else [np.asarray(f, dtype=float) for f in flows])
        if len(self.flows) != 2:
            raise ValueError('Expected forward and backward flow')
        for flow in self.flows:
            if flow.shape != self.grid.shape or not np.isfinite(flow).all():
                raise ValueError('Invalid flow')
            endpoint = self.grid + flow
            for axis, n in enumerate(self.a.shape[:2]):
                if endpoint[axis].min() < -1e-8 or endpoint[axis].max() > n - 1 + 1e-8:
                    raise ValueError('Flow leaves canvas')

    def frame(self, t):
        if not np.isfinite(t) or not 0 <= t <= 1:
            raise ValueError('Time must be in [0, 1]')
        u = clock(t)
        accum = np.zeros(self.a.shape, float)
        mass = np.zeros(self.a.shape[:2], float)
        deposits = []
        for colour, flow, progress, weight in zip(self.colours, self.flows, [u, 1-u], [1-u, u]):
            c, m = splat(colour, self.grid + progress*flow)
            accum += weight*c
            mass += weight*m
            deposits.append(float(m.sum()))
        missing = mass < 1e-10
        rgb = accum / np.maximum(mass[..., None], 1e-10)
        if missing.any():
            # Explicit gap policy, recorded in diagnostics; never silently black.
            nearest = ndi.distance_transform_edt(missing, return_distances=False, return_indices=True)
            rgb[missing] = rgb[tuple(nearest[:, missing])]
        image = np.rint(np.clip(srgb(rgb), 0, 1)*255).astype(np.uint8)
        return image, dict(missing_fraction=float(missing.mean()), deposited_mass=deposits,
                           density_range=[float(mass.min()), float(mass.max())])
