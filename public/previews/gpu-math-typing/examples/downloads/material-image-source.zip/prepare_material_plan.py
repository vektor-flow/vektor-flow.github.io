"""Build a semantic material plan from two images and their perception states."""
import argparse,json
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.interpolate import LinearNDInterpolator
from object_morph import ObjectMorph
from material_morph import geometric_coupling


def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('target',type=Path);p.add_argument('source_features',type=Path);p.add_argument('target_features',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
 a,b=[np.asarray(Image.open(f).convert('RGB')) for f in [args.source,args.target]]
 states=[dict(np.load(f)) for f in [args.source_features,args.target_features]]
 mesh=ObjectMorph(a,b,*states)
 grid=np.indices(a.shape[:2],dtype=float).reshape(2,-1).T
 forward=LinearNDInterpolator(mesh.source,mesh.target)(grid);backward=LinearNDInterpolator(mesh.target,mesh.source)(grid)
 source,target,mass=geometric_coupling(forward,backward,a.shape[:2])
 args.output.parent.mkdir(parents=True,exist_ok=True)
 np.savez_compressed(args.output,a=a,b=b,source_index=source,target_index=target,mass=mass)
 args.output.with_suffix('.json').write_text(json.dumps(dict(objects=mesh.objects,controls=mesh.controls,regularization=mesh.regularization,refinement=mesh.refinement),indent=2)+'\n')
 print(args.output)
if __name__=='__main__':main()
