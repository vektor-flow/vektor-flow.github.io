"""CPU perception adapter: instance masks and semantic patch descriptors.

Perception uses pretrained torchvision Mask R-CNN and Meta DINOv2 ViT-S/14.
Morph geometry is a separate stage; no manual landmarks enter this adapter.
"""
import argparse,json,sys,hashlib,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
import torch
from torchvision.models.detection import maskrcnn_resnet50_fpn,MaskRCNN_ResNet50_FPN_Weights


def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--dino-repo',type=Path,required=True);args=p.parse_args()
 torch.set_num_threads(4);torch.set_num_interop_threads(1)
 sys.path.insert(0,str(args.dino_repo))
 from dinov2.hub.backbones import dinov2_vits14
 detector=maskrcnn_resnet50_fpn(weights=MaskRCNN_ResNet50_FPN_Weights.COCO_V1,min_size=512,max_size=768).eval().to('cpu')
 encoder=dinov2_vits14(pretrained=True).eval().to('cpu')
 args.output.mkdir(parents=True,exist_ok=True);records=[]
 for name in ['cat','dog']:
  image=Image.open(args.source/f'{name}.png').convert('RGB');rgb=np.asarray(image)
  tensor=torch.from_numpy(rgb.copy()).permute(2,0,1).float()/255
  resized=torch.nn.functional.interpolate(tensor[None],(392,392),mode='bicubic',align_corners=False,antialias=True)
  normalized=(resized-torch.tensor([.485,.456,.406])[None,:,None,None])/torch.tensor([.229,.224,.225])[None,:,None,None]
  with torch.inference_mode():
   detected=detector([tensor])[0]
   features=encoder.forward_features(normalized)['x_norm_patchtokens'][0]
   features=torch.nn.functional.normalize(features,dim=-1).numpy().reshape(28,28,-1)
  keep=detected['scores']>.7
  masks=detected['masks'][keep,0].numpy();boxes=detected['boxes'][keep].numpy();labels=detected['labels'][keep].numpy();scores=detected['scores'][keep].numpy()
  categories=MaskRCNN_ResNet50_FPN_Weights.COCO_V1.meta['categories']
  np.savez_compressed(args.output/f'{name}.npz',features=features,masks=masks,boxes=boxes,labels=labels,scores=scores)
  overlay=rgb.astype(float)
  palette=[[50,210,240],[240,160,40],[230,80,140]]
  for j,mask in enumerate(masks):
   alpha=.3*(mask>.5)[...,None];overlay=overlay*(1-alpha)+np.array(palette[j%3])*alpha
  review=Image.fromarray(np.uint8(overlay));d=ImageDraw.Draw(review)
  for j,box in enumerate(boxes):d.rectangle(tuple(box),outline=tuple(palette[j%3]),width=2);d.text(tuple(box[:2]),f'{categories[labels[j]]} {scores[j]:.3f}',fill='white')
  review.save(args.output/f'{name}-objects.png')
  row=dict(image=name,objects=[dict(label=categories[l],score=float(s),box=list(map(float,b))) for l,s,b in zip(labels,scores,boxes)])
  records.append(row);print(json.dumps(row),flush=True)
 weights=Path(torch.hub.get_dir())/'checkpoints'
 report=dict(device='cpu',torch=torch.__version__,dino_commit=subprocess.check_output(['git','-C',str(args.dino_repo),'rev-parse','HEAD'],text=True).strip(),
             detector='torchvision Mask R-CNN ResNet50 FPN COCO_V1',descriptor='DINOv2 ViT-S/14 LVD142M',
             weight_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in weights.glob('*.pth')},images=records)
 (args.output/'perception.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
