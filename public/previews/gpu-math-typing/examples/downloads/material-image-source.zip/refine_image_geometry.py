"""Refine a coarse semantic image map without changing its canvas boundary.

Local optical flow is estimated AFTER the source has been aligned by the coarse
map. This makes it a detail correction, not a replacement for semantic matching.
A line search rejects folds and severe compression in the shared geometry.
"""
import numpy as np
from scipy import ndimage as ndi
from scipy.interpolate import LinearNDInterpolator
from photo_transport import estimate_flow,validate_image
from photo_mesh import PhotoMesh


def refine_geometry(a,b,source,target,spacing=8):
 a,b=validate_image(a),validate_image(b)
 if a.shape!=b.shape:raise ValueError('Canvas sizes differ')
 source,target=np.asarray(source,float),np.asarray(target,float)
 if source.shape!=target.shape or source.ndim!=2 or source.shape[1]!=2 or not np.isfinite(source).all() or not np.isfinite(target).all():raise ValueError('Invalid coarse correspondence')
 h,w=a.shape[:2];grid=np.indices((h,w),dtype=float).reshape(2,-1).T
 inverse=LinearNDInterpolator(target,source)(grid)
 if not np.isfinite(inverse).all():raise ValueError('Coarse correspondence must cover the canvas')
 warped=np.stack([ndi.map_coordinates(a[...,c],inverse.T,order=1,mode='nearest').reshape(h,w) for c in range(3)],axis=-1)
 residual=estimate_flow(warped,b,smooth=2)
 limit=min(h,w)/16
 residual=np.clip(residual,-limit,limit)
 plan=PhotoMesh(a,b,flow=np.zeros((2,h,w)),spacing=spacing)
 base=LinearNDInterpolator(source,target)(plan.source)
 if not np.isfinite(base).all():raise ValueError('Source geometry must cover the canvas')
 delta=np.column_stack([ndi.map_coordinates(f,base.T,order=1,mode='nearest') for f in residual])
 edge=np.minimum.reduce([plan.source[:,0],h-1-plan.source[:,0],plan.source[:,1],w-1-plan.source[:,1]])
 delta*=np.clip(edge/(min(h,w)/12),0,1)[:,None]
 for amount in [1.,.75,.5,.25,0.]:
  plan.target=np.clip(base+amount*delta,[0,0],[h-1,w-1])
  measurements=[plan.structure(float(t),timing='linear') for t in np.linspace(0,1,33)]
  if all(x['fold_fraction']==0 and x['compression_p05']>.12 for x in measurements):break
 else:raise ValueError('Coarse correspondence itself is not admissible')
 return plan.source,plan.target,plan.triangles,dict(residual_fraction=amount,maximum_correction_pixels=float(np.max(np.linalg.norm(plan.target-base,axis=1))),sampled_fold_fraction=max(x['fold_fraction'] for x in measurements),sampled_minimum_compression_p05=min(x['compression_p05'] for x in measurements),timing_samples=len(measurements))
