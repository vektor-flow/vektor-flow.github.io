"""Render an explicit work-in-progress material-transport review video."""
import argparse,json,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from material_morph import MaterialTransport


def main():
 p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('output',type=Path);args=p.parse_args()
 data=np.load(args.plan);plan=MaterialTransport(data['a'],data['b'],(data['source_index'],data['target_index'],data['mass']))
 out=args.output;out.mkdir(parents=True,exist_ok=True);h,w=plan.a.shape[:2]
 movie=out/'cat-dog-material-review.mp4'
 command=['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{w}x{h+64}','-framerate','30','-i','-','-vf','tpad=start_duration=0.7:stop_duration=0.7:start_mode=clone:stop_mode=clone','-c:v','libx264','-crf','13','-pix_fmt','yuv420p','-movflags','+faststart',str(movie)]
 process=subprocess.Popen(command,stdin=subprocess.PIPE);records=[]
 try:
  for k,t in enumerate(np.linspace(0,1,121)):
   pixels,info=plan.frame(float(t));records.append(dict(t=float(t),**info))
   panel=Image.new('RGB',(w,h+64),'#111b26');panel.paste(Image.fromarray(pixels),(0,64));draw=ImageDraw.Draw(panel)
   draw.text((12,10),'Cat to dog | moving material',fill='white')
   draw.text((12,30),'Refined object and feature alignment',fill='#9db8c8')
   draw.text((w-52,48),f'{t:.0%}',fill='#58d7de')
   process.stdin.write(np.asarray(panel).tobytes())
   if k%30==0:print(f'Review video {k}/120',flush=True)
  process.stdin.close()
  if process.wait()!=0:raise RuntimeError('Video encoding failed')
 except BaseException:
  process.kill();process.wait();raise
 (out/'report.json').write_text(json.dumps(dict(revision='material-refined-r5',status='work in progress; object split/merge acceptance remains open',backend='Python CPU reference',
  appearance='RGB changes along material paths; no endpoint image opacity envelopes',samples=records),indent=2)+'\n')
 print(movie,flush=True)
if __name__=='__main__':main()
