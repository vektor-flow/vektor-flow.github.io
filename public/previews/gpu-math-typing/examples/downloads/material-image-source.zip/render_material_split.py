"""Render inferred transport between TWO independently supplied RGBA images."""
import argparse,json,subprocess,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
from endpoint_transport import EndpointTransport


def composite(im,size):
 bg=Image.new('RGBA',im.size,'#111b26');bg.alpha_composite(im)
 return bg.convert('RGB').resize((size,size),Image.Resampling.LANCZOS)


def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('target',type=Path);p.add_argument('output',type=Path);args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 a=np.asarray(Image.open(args.source).convert('RGBA'));b=np.asarray(Image.open(args.target).convert('RGBA'))
 plan=EndpointTransport(a,b);print(f'Inferred {len(plan.source)} material paths from two states',flush=True)
 width=768;height=560
 movie=args.output/'material-split-merge.mp4';process=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{width}x{height}','-framerate','30','-i','-','-c:v','libx264','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(movie)],stdin=subprocess.PIPE)
 cache={};records=[];left=composite(Image.fromarray(a),176);right=composite(Image.fromarray(b),176)
 try:
  for index,t in enumerate(np.r_[np.zeros(24),np.linspace(0,1,121),np.ones(30),np.linspace(1,0,121),np.zeros(24)]):
   key=round(float(t),8)
   if key not in cache:cache[key]=plan.frame(float(t))
   frame,info=cache[key];records.append(info)
   panel=Image.new('RGB',(width,height),'#111b26');d=ImageDraw.Draw(panel)
   d.text((20,16),'TWO INPUT STATES  /  endpoint transport r4',fill='white')
   d.text((20,38),'Computed pixel correspondence | no angular wrapping',fill='#9db8c8')
   panel.paste(left,(8,184));panel.paste(composite(Image.fromarray(frame),384),(192,100));panel.paste(right,(584,184))
   d.text((24,162),'SOURCE INPUT',fill='white');d.text((610,162),'TARGET INPUT',fill='white')
   d.text((304,80),f'MORPH  {t:.2f}',fill='#69e5df')
   d.text((20,508),'One -> two, then the same correspondence in reverse',fill='white')
   d.text((20,530),'CPU masked-image prototype | area preservation still under review',fill='#9db8c8')
   process.stdin.write(np.asarray(panel).tobytes())
   if index in [24,54,84,114,144]:panel.save(args.output/f'endpoint-review-{index}.png')
  process.stdin.close()
  if process.wait()!=0:raise RuntimeError('Video encoding failed')
 except BaseException:process.kill();process.wait();raise
 report=dict(revision='endpoint-r4',automatic_correspondence=True,automatic_segmentation=False,appearance_changes=True,whole_image_crossfade=False,angular_wrapping=False,area_preservation=False,method='Global balanced assignment of foreground pixels, squared spatial distance; continuous local surface reconstruction',endpoint_areas=plan.endpoint_areas,endpoint_exact=all(np.array_equal(plan.frame(t)[0],im) for t,im in [(0,a),(1,b)]),inputs={name:dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for name,path in [('source',args.source),('target',args.target)]},samples=records)
 (args.output/'split-report.json').write_text(json.dumps(report,indent=2)+'\n');print(movie,flush=True)
if __name__=='__main__':main()
