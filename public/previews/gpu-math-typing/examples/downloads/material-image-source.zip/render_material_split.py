"""Known-map split/merge experiment: fixed texture samples, no recolouring.

This isolates material behavior; it is not an automatically inferred photo pair.
"""
import argparse,subprocess,json
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
from PIL import Image,ImageDraw
from image_transport import linear,srgb
from pixel_transport import clock


def main():
 p=argparse.ArgumentParser();p.add_argument('texture',type=Path);p.add_argument('output',type=Path);args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
 size=384;radius=104.;grid=np.indices((size*2,size*2),dtype=float).reshape(2,-1).T/2+.25
 local=grid-(size-1)/2;r=np.linalg.norm(local,axis=1);valid=r<=radius;source=grid[valid];local=local[valid];r=r[valid]
 angle=np.arctan2(local[:,0],local[:,1]);right=local[:,1]>=0
 phase=np.where(right,angle,(angle-np.pi+np.pi)%(2*np.pi)-np.pi)
 target=np.column_stack([np.sin(2*phase)*r/np.sqrt(2)+(size-1)/2,np.cos(2*phase)*r/np.sqrt(2)+np.where(right,277,106)])
 texture=np.asarray(Image.open(args.texture).convert('RGB').resize((size,size)))
 colour=np.column_stack([ndi.map_coordinates(linear(texture[...,c]/255.),source.T,order=1,mode='nearest') for c in range(3)])
 movie=args.output/'material-split-merge.mp4';process=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pixel_format','rgb24','-video_size','384x448','-framerate','30','-i','-','-c:v','libx264','-crf','13','-pix_fmt','yuv420p','-movflags','+faststart',str(movie)],stdin=subprocess.PIPE)
 records=[]
 try:
  for t in np.r_[np.zeros(15),np.linspace(0,1,91),np.ones(15),np.linspace(1,0,91),np.zeros(15)]:
   u=clock(t);coords=(1-u)*source+u*target;base=np.floor(coords).astype(int);fraction=coords-base
   mass=np.zeros(size*size);rgb=np.zeros((size*size,3))
   for dy,dx,ww in [(0,0,(1-fraction[:,0])*(1-fraction[:,1])),(0,1,(1-fraction[:,0])*fraction[:,1]),(1,0,fraction[:,0]*(1-fraction[:,1])),(1,1,fraction[:,0]*fraction[:,1])]:
    index=(base[:,0]+dy)*size+base[:,1]+dx;weight=ww/4
    mass+=np.bincount(index,weights=weight,minlength=size*size)
    for c in range(3):rgb[:,c]+=np.bincount(index,weights=weight*colour[:,c],minlength=size*size)
   rgb/=np.maximum(mass,1e-10)[:,None];rgb=srgb(rgb).reshape(size,size,3)
   occupied=mass.reshape(size,size)>.03
   rgb[~occupied]=np.array([17,27,38])/255.
   image=np.rint(np.clip(rgb,0,1)*255).astype(np.uint8)
   panel=Image.new('RGB',(size,size+64),'#111b26');panel.paste(Image.fromarray(image),(0,64));d=ImageDraw.Draw(panel)
   d.text((12,10),'One form -> two -> one',fill='white');d.text((12,30),'Fixed texture material | controlled split/merge test',fill='#9db8c8')
   process.stdin.write(np.asarray(panel).tobytes())
   records.append(dict(progress=float(t),mass=float(mass.sum()),visible_pixels=int(occupied.sum())))
  process.stdin.close()
  if process.wait()!=0:raise RuntimeError('Video encoding failed')
 except BaseException:process.kill();process.wait();raise
 (args.output/'split-report.json').write_text(json.dumps(dict(automatic_correspondence=False,appearance_changes=False,material_samples=len(source),samples=records),indent=2)+'\n');print(movie,flush=True)
if __name__=='__main__':main()
