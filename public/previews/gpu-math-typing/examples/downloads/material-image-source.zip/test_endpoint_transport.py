import unittest
import numpy as np
from endpoint_transport import EndpointTransport
from make_endpoint_fixture import states

class EndpointTests(unittest.TestCase):
 def test_two_independent_states_and_reverse(self):
  a,b=states(32);p=EndpointTransport(a,b)
  np.testing.assert_array_equal(p.frame(0)[0],a);np.testing.assert_array_equal(p.frame(1)[0],b)
  self.assertEqual(len(np.unique(p.target,axis=0)),np.count_nonzero(b[...,3]))
  for t in [0,.01,.25,.5,.75,.99,1]:
   frame,info=p.frame(t);self.assertAlmostEqual(info['mass'],np.count_nonzero(a[...,3]),places=8)
  # Reverse the very same plan, avoiding tie-dependent reassignment.
  q=EndpointTransport(b,a);q.source=p.target;q.target=p.source;q.ca=p.cb;q.cb=p.ca;q.mass=p.mass
  np.testing.assert_array_equal(p.frame(.3,False)[0],q.frame(.7,False)[0])
 def test_identity_and_translation_preserve_texture(self):
  a=np.zeros((24,24,4),np.uint8);a[5:15,3:9]=np.random.default_rng(2).integers(0,256,(10,6,4));a[5:15,3:9,3]=255
  p=EndpointTransport(a,a)
  for t in [0,.5,1]:np.testing.assert_array_equal(p.frame(t)[0],a)
  b=np.roll(a,8,axis=1);p=EndpointTransport(a,b)
  np.testing.assert_array_equal(p.target-p.source,np.tile([0,8],(60,1)))
  np.testing.assert_array_equal(p.frame(.5,False)[0],np.roll(a,4,axis=1))
 def test_target_bands_have_no_angular_seam(self):
  _,b=states(128)
  for row in b:
   colors=row[row[:,3]>0,:3]
   if len(colors):self.assertTrue(np.all(colors==colors[0]))
 def test_invalid(self):
  a,b=states(16)
  for t in [float('nan'),-1,1.1]:
   with self.assertRaises(ValueError):EndpointTransport(a,b).frame(t)
  with self.assertRaises(ValueError):EndpointTransport(a,b,max_samples=2)

if __name__=='__main__':unittest.main()
