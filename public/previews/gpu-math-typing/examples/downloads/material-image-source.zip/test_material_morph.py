import unittest
import numpy as np
from material_morph import MaterialTransport,geometric_coupling


class MaterialTests(unittest.TestCase):
 def test_identity_has_one_population_and_exact_pixels(self):
  a=np.random.default_rng(71).integers(0,256,(16,16,3),dtype=np.uint8)
  grid=np.indices((16,16),dtype=float).reshape(2,-1).T
  coupling=geometric_coupling(grid,grid,(16,16));self.assertEqual(len(coupling[0]),256)
  plan=MaterialTransport(a,a,coupling)
  for t in [0,.25,.5,.75,1]:
   im,info=plan.frame(t);np.testing.assert_array_equal(im,a);self.assertAlmostEqual(info['material_mass'],256)
 def test_split_and_combine_are_mass_carrying_edges(self):
  a=np.random.default_rng(72).integers(0,256,(8,8,3),dtype=np.uint8);b=np.flip(a,axis=1).copy()
  source=np.r_[np.arange(64),0,0];target=np.r_[np.arange(64),1,2];mass=np.ones(66);mass[[0,64,65]]=1/3
  p=MaterialTransport(a,b,(source,target,mass));q=MaterialTransport(b,a,(target,source,mass))
  np.testing.assert_array_equal(p.frame(0)[0],a);np.testing.assert_array_equal(p.frame(1)[0],b)
  for t in [.2,.5,.8]:
   im,info=p.frame(t,timing='linear');back=q.frame(1-t,timing='linear')[0]
   np.testing.assert_array_equal(im,back);self.assertAlmostEqual(info['material_mass'],64)
   self.assertEqual(info['splitting_samples'],1);self.assertEqual(info['combining_destinations'],2)
 def test_incomplete_or_negative_mass_rejected(self):
  a=np.zeros((8,8,3),np.uint8);index=np.arange(64)
  with self.assertRaises(ValueError):MaterialTransport(a,a,(index,index,np.full(64,-1)))
  with self.assertRaises(ValueError):MaterialTransport(a,a,(index,np.zeros(64,dtype=int),np.ones(64)))
  p=MaterialTransport(a,a,(index,index,np.ones(64)))
  with self.assertRaises(ValueError):p.frame(float('nan'))

if __name__=='__main__':unittest.main()
