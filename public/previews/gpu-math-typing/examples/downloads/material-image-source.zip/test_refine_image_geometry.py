import unittest
import numpy as np
from scipy import ndimage as ndi
from scipy.interpolate import LinearNDInterpolator
from photo_mesh import PhotoMesh
from refine_image_geometry import refine_geometry

class RefinementTests(unittest.TestCase):
 def image(self):
  y,x=np.indices((64,64));a=30+170*np.exp(-((y-24)**2+(x-22)**2)/70)+110*np.exp(-((y-43)**2+(x-38)**2)/25)
  return np.repeat(np.rint(a)[...,None],3,axis=2).clip(0,255).astype(np.uint8)
 def test_identity_does_not_invent_motion(self):
  a=self.image();mesh=PhotoMesh(a,a,flow=np.zeros((2,64,64)),spacing=8)
  source,target,triangles,report=refine_geometry(a,a,mesh.source,mesh.target)
  np.testing.assert_allclose(source,target,atol=1e-5);self.assertEqual(report['sampled_fold_fraction'],0)
 def test_coarse_alignment_is_refined_without_moving_canvas(self):
  a=self.image();b=ndi.shift(a,(0,4,0),order=1,mode='nearest');mesh=PhotoMesh(a,b,flow=np.zeros((2,64,64)),spacing=8)
  source,target,triangles,report=refine_geometry(a,b,mesh.source,mesh.target)
  edge=np.any((source==0)|(source==63),axis=1);np.testing.assert_array_equal(source[edge],target[edge])
  grid=np.indices((64,64)).reshape(2,-1).T;inverse=LinearNDInterpolator(target,source)(grid)
  warped=ndi.map_coordinates(a[...,0].astype(float),inverse.T,order=1,mode='nearest').reshape(64,64)
  before=np.mean(np.abs(a[...,0].astype(float)-b[...,0]));after=np.mean(np.abs(warped-b[...,0]))
  self.assertLess(after,.5*before);self.assertGreater(report['maximum_correction_pixels'],2);self.assertEqual(report['sampled_fold_fraction'],0)
 def test_invalid_inputs_rejected(self):
  a=self.image();mesh=PhotoMesh(a,a,flow=np.zeros((2,64,64)),spacing=8)
  bad=mesh.target.copy();bad[0]=np.nan
  with self.assertRaises(ValueError):refine_geometry(a,a,mesh.source,bad)
  with self.assertRaises(ValueError):refine_geometry(a,a[:32],mesh.source,mesh.target)

if __name__=='__main__':unittest.main()
