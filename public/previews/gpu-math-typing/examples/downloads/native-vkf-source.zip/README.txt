Experimental CPU-native VKF morphology sources. Qualified with native compiler 0.7.2. Includes state interpolation, solid primitives and indexed scan mesh extraction.
