Experimental CPU-native VKF morphology sources. Qualified with native compiler 0.7.2. Includes image flow/mesh, state interpolation, solid primitives and indexed scan mesh extraction.
